#--------------------------------------------------------------------------------------------------------------------------
# Estimation of the (excess) hazard via multidimensional penalized splines for time-to-event data
#--------------------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# datCancer : simulated cancer dataset
#----------------------------------------------------------------------------------------------------------------

#' Patients diagnosed with cervical cancer
#'
#' A simulated dataset containing the follow-up times of 2000 patients diagnosed with cervical cancer between 
#' 1990 and 2010. End of follow-up is 30/06/2013. The variables are as follows:
#' \itemize{
#'   \item begin. beginning of follow-up. For illustration purposes about left truncation only (0--1)
#'   \item fu. follow-up time in years (0--5)
#'   \item age. age at diagnosis in years, from 21.39 to 99.33
#'   \item yod. decimal year of diagnosis, from 1990.023 to 2010.999
#'   \item dead. censoring indicator (1 for dead, 0 for censored)
#'   \item rate. expected mortality rate (from overall mortality of the general population) (0--0.38)
#' }
#' @docType data
#' @keywords datasets
#' @name datCancer
#' @usage data(datCancer)
#' @format A data frame with 2000 rows and 6 variables
NULL


#----------------------------------------------------------------------------------------------------------------
# END of code : datCancer
#----------------------------------------------------------------------------------------------------------------




#----------------------------------------------------------------------------------------------------------------
# tensor.in : constructs the design matrix for a tensor product from two marginals design matrices
#----------------------------------------------------------------------------------------------------------------

#' tensor model matrix for two marginal bases
#'
#' Function called recursively inside \code{\link{tensor.prod.X}}.
#'
#' @param X1 first marginal design matrix with n rows and p1 columns
#' @param X2 first marginal design matrix with n rows and p2 columns
#' @return Matrix of dimensions n*(p1*p2) representing the row tensor product of the matrices X1 and X2
#' @export
#'
tensor.in <- function(X1,X2){

	# each column of X1 is multiplied by all the columns of X2
	l <- lapply(1:ncol(X1),function(i) {X1[,i]*X2})
	do.call(cbind, l)
	
}

#----------------------------------------------------------------------------------------------------------------
# END of code : tensor.in
#----------------------------------------------------------------------------------------------------------------




#----------------------------------------------------------------------------------------------------------------
# tensor.prod.X : constructs the design matrix for a tensor product from the marginals design matrices
#----------------------------------------------------------------------------------------------------------------

#' tensor model matrix
#'
#' Computes the model matrix of tensor product smooth from the marginal bases.
#'
#' @param X list of m design matrices with n rows and p1, p2, ... pm columns respectively
#' @return
#' \item{T}{Matrix of dimensions n*(p1*p2*...*pm) representing the row tensor product of the matrices in X}
#' @export
#'
tensor.prod.X <- function (X) 
{
    m <- length(X) # number of matrices
	
	if(m>1){
	
		# starts with the first two matrices
		T <- tensor.in(X[[1]],X[[2]])

		if(m>2){ # repeats the function tensor.in from the previous result, one matrix at a time
			for (j in 3:m){
			
				T <- tensor.in(T,X[[m]])
			
			}
		}
		
	}else{
		# if there is only one matrix in the list X, we return that matrix
		T <- X[[1]]
	
	}

    T
}

#----------------------------------------------------------------------------------------------------------------
# END of code : tensor.prod.X
#----------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------
# tensor.prod.S : equivalent to function tensor.prod.penalties from mgcv package
#----------------------------------------------------------------------------------------------------------------

#' Tensor product for penalty matrices
#'
#' Computes the penalty matrices of a tensor product smooth from the marginal penalty matrices. The code is from
#' function \code{tensor.prod.penalties} in \code{mgcv} package.
#'
#' @param S list of m marginal penalty matrices
#' @return
#' \item{TS}{List of the penalty matrices associated with the tensor product smooth}
#' @export
#'
tensor.prod.S <- function (S) 
{
    m <- length(S)
    I <- vector("list", m)
    for (i in 1:m) {
        n <- ncol(S[[i]])
        I[[i]] <- diag(n)
    }
    TS <- vector("list", m)
    if (m == 1) 
        TS[[1]] <- S[[1]]
    else for (i in 1:m) {
        if (i == 1) 
            M0 <- S[[1]]
        else M0 <- I[[1]]
        for (j in 2:m) {
            if (i == j) 
                M1 <- S[[i]]
            else M1 <- I[[j]]
            M0 <- M0 %x% M1
        }
        TS[[i]] <- if (ncol(M0) == nrow(M0)) 
            (M0 + t(M0))/2
        else M0
    }
    TS
}

#----------------------------------------------------------------------------------------------------------------
# END of code : tensor.prod.S
#----------------------------------------------------------------------------------------------------------------




#----------------------------------------------------------------------------------------------------------------
# crs : bases for cubic regression splines (equivalent to the "cr" in mgcv)
#----------------------------------------------------------------------------------------------------------------

#' Bases for cubic regression splines (equivalent to "cr" in \code{mgcv})
#'
#' Builds the design matrix and the penalty matrix for cubic regression splines.
#'
#' @param x Numeric vector
#' @param knots Numeric vectors that specifies the knots of the splines (including boundaries); default is NULL
#' @param df numeric value that indicates the number of knots desired (or degrees of freedom) if knots=NULL; default is 10
#' @param intercept if FALSE, the intercept is excluded from the basis; default is TRUE
#' @details
#' See package \code{mgcv} and section 4.1.2 of Wood (2006) for more details about this basis
#' @return List of three elements
#' \item{bs}{design matrix}
#' \item{pen}{penalty matrix}
#' \item{knots}{vector of knots (specified or calculated from \code{df})}
#' @export
#'
#' @references
#' Wood, S. N. (2006), Generalized additive models: an introduction with R. London: Chapman & Hall/CRC.
#'
#' @examples
#' x <- seq(1,10,length=100)
#' crs(x,knots=c(1,5,10))
#'
crs <- function(x, knots=NULL,df=10, intercept=TRUE) {

  n <- length(x)

  if (is.null(knots)) # space knots through data if knots are unspecified
  {
    if (is.null(df)) {df <- 10}
    if(df<3) {stop("Number of knots should be at least 3, 1 interior plus 2 boundaries")}

    if(n<2) {stop("Please specify at least 2 values or specify at least 3 knots via knots=...")}
    knots <- stats::quantile(unique(x),seq(0,1,length=df))
    # if you don't use unique(x), the penalization matrix can be non positive semi definite
  }

  k <- length(knots)

  if (k<3) {stop("Please specify at least 3 knots, 1 interior plus 2 boundaries")}

  knots <- sort(knots)

  h <- diff(knots)

  F.P <- crs.FP(knots,h)

  # matrix mapping beta to delta (the values at the knots of the second derivative of the splines, see section 4.1.2
  # of )
  F.mat <- F.P$F.mat
  F.mat1 <- rbind(rep(0,k),F.mat)
  F.mat2 <- rbind(F.mat,rep(0,k))

  # penalty matrix
  P.mat <- F.P$P.mat 

  # to project beyond the boundaries
  condition.min <- rep(0,n)
  condition.min[x<min(knots)] <- 1

  condition.max <- rep(0,n)
  condition.max[x>max(knots)] <- 1

  x.min <- x[condition.min==1]

  x.max <- x[condition.max==1]

  len.min <- length(x.min)
  
  len.max <- length(x.max)
  
  x[condition.min==1] <- min(knots)

  x[condition.max==1] <- max(knots)

  # interval condition matrix (to which interval belongs each x value)
  condition <- matrix(0,nrow=n,ncol=k-1)
  
  for (l in 1:(k-1)){

    # Careful to the knots that belong to two intervals : we define the spline function on
    # right-open intervals
    condition[(x >= knots[l]) & (x < knots[l+1]),l] <- 1
	
  }
  
  # position bases
  a.minus <- sapply(1:(k-1),function(l) (knots[l+1]-x)/h[l])
  a.plus <- sapply(1:(k-1),function(l) (x-knots[l])/h[l])
  
  # curvature bases
  c.minus <- 1/6*sapply(1:(k-1),function(l) (knots[l+1]-x)^3/h[l]  -  h[l]*(knots[l+1]-x))
  c.plus <- 1/6*sapply(1:(k-1),function(l) (x-knots[l])^3/h[l]  -  h[l]*(x-knots[l]))
  
  # we multiply by every interval condition
  a.minus <- a.minus*condition
  a.plus <- a.plus*condition
  
  c.minus <- c.minus*condition
  c.plus <- c.plus*condition
  
  # position bases conditions
  Ident <- diag(k-1)
  Mat_j <- cbind(Ident,rep(0,k-1))
  Mat_j_1 <- cbind(rep(0,k-1),Ident)
  
  # bases
  b <- c.minus%*%F.mat1+c.plus%*%F.mat2+a.minus%*%Mat_j+a.plus%*%Mat_j_1
  
  # Since we defined the spline function on right-open intervals, the last knots is not taken into account.
  # That's why we add 1 manually into the design matrix
  if(any(x == max(knots))) b[x == max(knots), k] <- 1
  
  # to project beyond the boundaries
  if (sum(condition.min)>0){
  
	v1 <- (x.min-min(knots))
	v2 <- -h[1]/6*F.mat[1,]-1/h[1]*c(1,rep(0,k-1))+1/h[1]*c(0,1,rep(0,k-2))
	
	b[condition.min==1,] <- b[condition.min==1,]+
	matrix(v1*rep(v2,each=len.min),nrow=len.min,ncol=k)
	
  }
  
  if (sum(condition.max)>0){
  
	v1 <- (x.max-max(knots))
	v2 <- h[k-1]/6*F.mat[k-2,]-1/h[k-1]*c(rep(0,k-2),1,0)+1/h[k-1]*c(rep(0,k-1),1)
	
	b[condition.max==1,] <- b[condition.max==1,]+
	matrix(v1*rep(v2,each=len.max),nrow=len.max,ncol=k)
	
  }
  
  if(intercept == FALSE) {
    return(list(bs=b[,-1],pen=P.mat[-1,-1]))
  } else {
    return(list(bs=b,pen=P.mat,knots=knots))
  }

}

#----------------------------------------------------------------------------------------------------------------
# END of code : crs
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# crs.FP : called inside crs to get the penalty matrix
#----------------------------------------------------------------------------------------------------------------

#' Penalty matrix constructor for cubic regression splines
#'
#' constructs the penalty matrix associated with cubic regression splines basis. This function is called inside
#' \code{\link{crs}}.
#'
#' @param knots Numeric vectors that specifies the knots of the splines (including boundaries)
#' @param h vector of knots differences (corresponds to \code{diff(sort(knots))})
#' @return List of two elements:
#' \item{F.mat}{matrix used in function \code{\link{crs}} for basis construction}
#' \item{P.mat}{penalty matrix}
#' @export
#'
crs.FP <- function(knots,h){
  # constraints of second derivatives continuity and nullity beyond the boundaries

  k <- length(knots)

  if (k<3) {stop("Please specify at least 3 knots, 1 interior plus 2 boundaries")}
  
  B <- matrix(0,nrow=k-2,ncol=k-2)

  D <- matrix(0,nrow=k-2,ncol=k)

  for (i in 1:(k-2)){

    D[i,i] <- 1/h[i]

    D[i,i+1] <- -1/h[i]-1/h[i+1]

    D[i,i+2] <- 1/h[i+1]

    B[i,i] <- (h[i]+h[i+1])/3

	if(i<(k-2)){
	
		B[i,i+1] <- B[i+1,i] <- h[i+1]/6
		
	}
	  
  }

  F.mat <- chol2inv(chol(B))%*%D

  P.mat <- t(D)%*%F.mat # penalty matrix

  P.mat <- (P.mat+t(P.mat))*0.5 # to make sure the penalty matrix is symmetric

  return(list(F.mat=F.mat,P.mat=P.mat))

}

#----------------------------------------------------------------------------------------------------------------
# END of code : crs.FP
#----------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------
# add, tensor and tint : key words to put inside a formula object to define penalized splines
# Multiple "add", "tensor" or "tint" calls are accpeted
#----------------------------------------------------------------------------------------------------------------

#' Define a unidimensional cubic regression splines inside a formula object
#'
#' Used inside a formula object to specify a covariate which is to be modelled as penalized cubic regression splines.
#' Equivalent to \code{s(...,bs="cr")} in \code{mgcv}.
#' @param ... name of the covariate
#' @param knots numeric vector that specifies the knots of the splines (including boundaries); default is NULL, in which case the knots are spread evenly through the covariate values
#' @param df numeric value that indicates the number of knots (or degrees of freedom) desired; default is NULL. If knots and df are NULL, df will be set to 10 and the knots will be spread evenly through the covariate values
#' @return object of class \code{add.smooth.spec}  (see \code{\link{smooth.spec}} for details)
#'
#' @export
#'
#' @examples
#' # cubic regression spline of time with 5 unspecified knots
#' formula.test <- ~add(time,df=5)
#'
#' # cubic regression splines of time and age with respectively 5 and 7 unspecified knots
#' formula.test2 <- ~add(time,df=5)+add(age,df=7)
#'
#' # cubic regression splines of time and age with respectively 3 and 4 specified knots
#' formula.test3 <- ~add(time,knots=c(0,3,5))+add(age,knots=c(30,50,70,90))
#'
add <- function(..., knots=NULL,df=NULL){

  smooth.spec(..., knots=knots,df=df,option="add")

}

#' Define a tensor product spline inside a formula object
#'
#' Used inside a formula object to specify which covariates are to be modelled as one tensor product spline.
#' Equivalent to \code{te(...,bs="cr")} in \code{mgcv}.
#' @param ... Any number of covariates separated by ","
#' @param knots List of numeric vectors that specifies the knots of the splines (including boundaries) for each covariate; default is NULL
#' @param df vectors of numeric values that indicates the number of knots (or degrees of freedom) desired for each covariate; default is NULL. If knots and df are NULL, df will be set to 5 for each covariate and the knots will be spread evenly through the covariate values
#' @return object of class tensor.smooth.spec  (see \code{\link{smooth.spec}} for details)
#'
#' @export
#'
#' @examples
#' # tensor product for time and age with respectively 5 and 4 unspecified knots
#' formula.test <- ~tensor(time,age,df=c(5,4))
#'
#' # tensor product for time and age with respectively 3 and 4 specified knots
#' formula.test3 <- ~tensor(time,agec,knots=list(c(0,3,5),c(30,50,70,90)))
#'
#' # tensor product for time, age and year with respectively 6, 5 and 4 unspecified knots
#' formula.test <- ~tensor(time,age,year,df=c(6,5,4))
#'
tensor <- function(..., knots=NULL,df=NULL){

  smooth.spec(..., knots=knots,df=df,option="tensor")

}

#' Define a tensor product interaction inside a formula object
#'
#' Used inside a formula object to specify which covariates are to be modelled as one tensor product interaction (while \code{\link{tensor}}
#' builds a tensor product of marginal bases including the intercepts, \code{tint} applies a tensor product of the marginal bases without their intercepts).
#' Unlike \code{\link{tensor}}, the marginal effects of the covariates should also be present in the formula.
#' Equivalent to \code{ti(...,bs="cr")} in \code{mgcv}.
#' @param ... Any number of covariates separated by ","
#' @param knots List of numeric vectors that specifies the knots of the splines (including boundaries) for each covariate; default is NULL
#' @param df vectors of numeric values that indicates the number of knots (or degrees of freedom) desired for each covariate; default is NULL. If knots and df are NULL, df will be set to 5 for each covariate and the knots will be spread evenly through the covariate values
#' @return object of class \code{tint.smooth.spec} (see \code{\link{smooth.spec}} for details)
#'
#' @export
#'
#' @examples
#' # tensor product interaction for time and age with respectively 5 and 4 unspecified knots
#' # main effects are specified as cubic regression splines
#' formula.test <- ~add(time,df=5)+add(age,df=4)+tint(time,age,df=c(5,4))
#'
tint <- function(..., knots=NULL,df=NULL){

  smooth.spec(..., knots=knots,df=df,option="tint")

}


#----------------------------------------------------------------------------------------------------------------
# End of code : add, tensor and tint
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# smooth.spec : function called by the wrappers add, tensor and tint
# The function does not construct any bases or penalty matrices, it just specifies the covariates
# that will be dealt as penalized splines, the dimensions of those splines, plus all the knots and
# degrees of freedom
#----------------------------------------------------------------------------------------------------------------

#' Covariates specified as penalized splines
#'
#' Specifies the covariates to be considered as penalized splines.
#'
#' @param ... Numeric vectors specified in \code{\link{add}}, \code{\link{tensor}} or \code{\link{tint}}
#' @param knots List of numeric vectors that specifies the knots of the splines (including boundaries); default is NULL
#' @param df Degrees of freedom : numeric vector that indicates the number of knots desired for each covariate; default is NULL
#' @param option "add", "tensor" or "tint". Depends on the wrapper function; default is "add"
#' @return object of class smooth.spec
#' \item{term}{Vector of strings giving the names of each covariate specified in ...}
#' \item{dim}{Numeric value giving the number of covariates associated with this spline}
#' \item{knots}{list of numeric vectors that specifies the knots for each covariate}
#' \item{df}{Numeric vector giving the number of knots associated with each covariate}
#' @export
#'
smooth.spec <- function(..., knots=NULL,df=NULL,option=NULL){

  if (is.null(option)) {
    option <- "add"
  }else{
    if (!option %in% c("tensor","add","tint")) stop("option must be : add, tensor or tint")
  }

  # By default, variables specified as "add" splines get 10 degrees of freedom,
  # varibales specified inside "tensor" calls get 5
  if (option!="add") {
    df.def <- 5

  }else{

    df.def <- 10
  }

  # We get information about the numbre of covariates and their names
  vars <- as.list(substitute(list(...)))[-1]
  dim <- length(vars)

  term <- deparse(vars[[1]], backtick = TRUE)
  if (dim > 1) {
    for (i in 2:dim) term[i] <- deparse(vars[[i]], backtick = TRUE)
  }
  for (i in 1:dim) term[i] <- attr(stats::terms(stats::reformulate(term[i])), "term.labels")

  if (length(unique(term)) != dim) {
    stop("Repeated variables as arguments of a smooth are not permitted")
  }


  if (is.null(knots)) {

	if (is.null(df)) {
		
		df <- rep(df.def,dim)
			
	}else{
		
		if (length(df)!=dim){
			
			df <- rep(df.def,dim)
			warning("wrong df length, df put to ",df.def," for each covariate")
				
		}
		
	}
		
  }else{

    if(!is.list(knots)) {

        if(dim>1) stop("knots must be a list argument")

        knots <- list(knots)

    }

    if (length(knots)!=dim){
	
        df <- rep(df.def,dim)
        knots <- NULL
        warning("wrong list of knots, df put to ",df.def," for each covariate and quantiles used")
		
    }else{

		df.temp	<- sapply(knots,FUN=length)
        
		if (is.null(df)) {
		
			df <- df.temp
		
		}else{
		
			if (any(df!=df.temp)){
		
				df <- df.temp
				if (all(df>2)) warning("wrong df, df put to ",df.temp)
		
			}
		}
		
    }

  }

  spec <- list(term=term,dim=dim,knots=knots,df=df)
  class(spec) <- paste(option,".smooth.spec",sep="")
  spec
}

#----------------------------------------------------------------------------------------------------------------
# END of code : smooth.spec
#----------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------
# smooth.cons : for each penalized spline, the function builds the design and penalty matrices
#----------------------------------------------------------------------------------------------------------------

#' Design and penalty matrices of penalized splines in a smooth.spec object
#'
#' Builds the design and penalty matrices from the result of \code{\link{smooth.spec}}.
#' @param term Vector of strings that generally comes from the value "term" of a \code{smooth.spec} object
#' @param knots List of numeric vectors that specifies the knots of the splines (including boundaries)
#' @param df Degrees of freedom : numeric vector that indicates the number of knots desired for each covariate
#' @param option "add", "tensor" or "tint"
#' @param data.spec data frame that represents the environment from which the covariate values and knots are to be calculated; default is NULL.
#' @return List of objects with the following items:
#' \item{X}{Design matrix}
#' \item{pen}{List of penalty matrices}
#' \item{term}{Vector of strings giving the names of each covariate}
#' \item{knots}{list of numeric vectors that specifies the knots for each covariate}
#' \item{dim}{Number of covariates}
#' \item{all.df}{Numeric vector giving the number of knots associated with each covariate}
#' \item{sum.df}{Sum of all.df}
#' \item{Z.add}{List of matrices that represents the sum-to-zero constraint to apply for "add" splines}
#' \item{Z.tensor}{List of matrices that represents the sum-to-zero constraint to apply for "tensor" splines}
#' \item{Z.tint}{List of matrices that represents the sum-to-zero constraint to apply for "tint" splines}
#' @export
#'
smooth.cons <- function(term, knots, df, option, data.spec){

  dim <- length(term)

  all.df <- if(!is.null(knots)){sapply(knots,length)}else{df}
  # for "add" splines, we must remove the intercept for all covariates but one
  all.df <- all.df+rep(if(option=="add"){-1}else{0},dim)

  sum.df <- sum(all.df)

  Base <- vector("list", dim) # list containing all design and penalty matrices for each covariate
  bs <- vector("list", dim) # design matrices
  pen <- vector("list", dim) # penalty matrices

  Z.add <- vector("list", dim) # matrices of sum-to-zero constraint
  Z.tint <- vector("list", dim) # matrices of sum-to-zero constraint

  if (option=="add") sum.temp <- 1

  knots2 <- vector("list", dim)

  for (i in 1:dim){

    Base[[i]] <- crs(eval(parse(text=term[i]),envir=as.environment(data.spec)),knots=knots[[i]],df=df[i],intercept=TRUE)

    bs[[i]] <- Base[[i]]$bs

	  knots2[[i]] <- Base[[i]]$knots

    # For each "add" spline, we apply the sum-to-zero constraint
    if (option=="add")  {

      contr.add <- constraint(bs[[i]],Base[[i]]$pen)

      bs[[i]] <- contr.add$X

      pen[[i]] <- matrix(0,nrow=sum.df,ncol=sum.df)

      pen[[i]][(sum.temp:(sum.temp+all.df[i]-1)),(sum.temp:(sum.temp+all.df[i]-1))] <- contr.add$S

      sum.temp <- sum.temp+all.df[i]

      Z.add[[i]] <- contr.add$Z

    }else{

	  if (option=="tint")  {

		contr.tint <- constraint(bs[[i]],Base[[i]]$pen)

		bs[[i]] <- contr.tint$X

		pen[[i]] <- contr.tint$S

		Z.tint[[i]] <- contr.tint$Z

		}else{

		  pen[[i]] <- Base[[i]]$pen

		  Z.add <- NULL

		}

    }

  }


  if (option!="add") {

	  # For a tensor product spline, the sum-to-zero constraint is not applied on the marginal matrices but after
	  # the creation of the multidimensionnal basis
	if (option=="tensor") {
	    contr.tensor <- constraint(tensor.prod.X(bs),tensor.prod.S(pen))
		X <- contr.tensor$X
		pen <- contr.tensor$S

		Z.tensor <- contr.tensor$Z
	    Z.tint <- NULL
    }

	  # For a tensor product spline tint, the sum-to-zero constraint is applied on the marginal matrices before
	  # the creation of the multidimensionnal basis
	if (option=="tint") {

		X <- tensor.prod.X(bs)
		pen <- tensor.prod.S(pen)

		Z.tensor <- NULL
	}

  }else{

	X <- do.call(cbind,bs)
	Z.tensor <- NULL

  }

  list(X=X,pen=pen,term=term,knots=knots2,dim=dim,all.df=all.df,sum.df=sum.df,Z.tensor=Z.tensor,Z.add=Z.add,Z.tint=Z.tint)

}

#----------------------------------------------------------------------------------------------------------------
# END of code : smooth.cons
#----------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------
# constraint : applies the sum-to-zero constraint
#----------------------------------------------------------------------------------------------------------------

#' Sum-to-zero constraint
#'
#' Applies the sum-to-zero constraints to design and penalty matrices.
#'
#' @param X A design matrix
#' @param S A penalty matrix or a list of penalty matrices
#' @param Z A list of sum-to-zero constraint matrices; default is NULL
#' @return List of objects with the following items:
#' \item{X}{Design matrix}
#' \item{S}{Penalty matrix or list of penalty matrices}
#' \item{Z}{List of sum-to-zero constraint matrices}
#' @export
#'
constraint <- function(X,S,Z=NULL){

  if (is.null(Z)){

	C <- colSums(X)

	qrc <- qr(C)

	Z <- qr.Q(qrc,complete=TRUE)[,2:length(C)]

  }

  # Reparametrized design matrix
  XZ <- X%*%Z

  # Reparametrized penalty matrix (or matrices)
  if(is.list(S)){

	length.S <- length(S)
	
	SZ <- lapply(1:length.S,function(i) t(Z)%*%S[[i]]%*%Z)

  }else{

    SZ <- t(Z)%*%S%*%Z

  }

  list(X=XZ,S=SZ,Z=Z)

}

#----------------------------------------------------------------------------------------------------------------
# END of code : constraint
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# smooth.cons.integral : almost identical to smooth.cons. This version is called inside the Gauss-Legendre
# quadrature. Here, the sum-to-zero constraints must be specified so that they correspond to the ones that
# were calculated with the initial dataset
#----------------------------------------------------------------------------------------------------------------

#' Design matrix of penalized splines in a smooth.spec object for Gauss-Legendre quadrature
#'
#' Almost identical to \code{\link{smooth.cons}}. This version is dedicated to Gauss-Legendre
#' quadrature. Here, the sum-to-zero constraints must be specified so that they correspond to the ones that
#' were calculated with the initial dataset.
#'
#' @param term Vector of strings that generally comes from the value "term" of a smooth.spec object
#' @param knots List of numeric vectors that specifies the knots of the splines (including boundaries)
#' @param df Degrees of freedom : numeric vector that indicates the number of knots desired for each covariate
#' @param option "add", "tensor" or "tint"
#' @param data.spec data frame that represents the environment from which the covariate values and knots are to be calculated; default is NULL.
#' @param Z.add List of matrices that represents the sum-to-zero constraint to apply for \code{\link{add}} splines
#' @param Z.tensor List of matrices that represents the sum-to-zero constraint to apply for \code{\link{tensor}} splines
#' @param Z.tint List of matrices that represents the sum-to-zero constraint to apply for \code{\link{tint}} splines
#' @return design matrix
#' @export
#'
smooth.cons.integral <- function(term, knots, df, option, data.spec, Z.add, Z.tensor, Z.tint){

  dim <- length(term)

  Base <- vector("list",dim) # list containing all design and penalty matrices for each covariate
  bs <- vector("list", dim) # design matrices

  if (option=="add") sum.temp=1

  for (i in 1:dim){

    Base[[i]] <- crs(eval(parse(text=term[i]),envir=as.environment(data.spec)),knots=knots[[i]],df=df[i],intercept=TRUE)

    bs[[i]] <- Base[[i]]$bs

    # For each "add" spline, we apply the sum-to-zero constraint
    if (option=="add")  {

      bs[[i]] <- bs[[i]]%*%Z.add[[i]]

    }

	if (option=="tint")  {

      bs[[i]] <- bs[[i]]%*%Z.tint[[i]]

    }

  }

  if (option!="add") {

	if (option=="tensor") {

    X <- tensor.prod.X(bs)%*%Z.tensor

    }

	if (option=="tint") {

    X <- tensor.prod.X(bs)

    }

  }else{

    X <- do.call(cbind,bs)

  }

  return(X)

}

#----------------------------------------------------------------------------------------------------------------
# END of code : smooth.cons.integral
#----------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------
# model.cons : based on the model formula, builds the global design matrix and penalty matrices
#----------------------------------------------------------------------------------------------------------------

#' Design and penalty matrices for the model
#'
#' Sets up the model before optimization. Builds the design matrix, the penalty matrix and all the design matrices needed for Gauss-Legendre quadrature.
#'
#' @param formula formula object identifying the model
#' @param lambda vector of smoothing parameters
#' @param data.spec data frame that represents the environment from which the covariate values and knots are to be calculated
#' @param t1 vector of follow-up times
#' @param t1.name name of \code{t1} in \code{data.spec}
#' @param t0 vector of origin times (usually filled with zeros)
#' @param t0.name name of \code{t0} in \code{data.spec}
#' @param event vector of censoring indicators
#' @param event.name name of event in \code{data.spec}
#' @param expected vector of expected hazard
#' @param expected.name name of expected in \code{data.spec}
#' @param type "net" or "overall"
#' @param n.legendre number of nodes for Gauss-Legendre quadrature
#' @param cl original \code{survPen} call
#' @return List of objects with the following items:
#' \item{cl}{original \code{survPen} call}
#' \item{type}{"net" or "overall"}
#' \item{n.legendre}{number of nodes for Gauss-Legendre quadrature}
#' \item{n}{number of individuals}
#' \item{p}{number of parameters}
#' \item{X.para}{design matrix associated with the full parametric coefficients}
#' \item{X.smooth}{design matrix associated with the penalized coefficients}
#' \item{X}{design matrix for the model}
#' \item{T.X}{transpose of \code{X}}
#' \item{leg}{list of nodes and weights for Gauss-Legendre integration on [-1;1] as returned by \code{\link[statmod]{gauss.quad}}}
#' \item{X.GL}{list of matrices (\code{length(X.GL)=n.legendre}) for Gauss-Legendre quadrature}
#' \item{T.X.GL}{list of the transposes of the elements of \code{X.GL}}
#' \item{X.GL.w.tm}{list whose elements are \code{X.GL[[i]]*leg$weights[i]*tm}}
#' \item{S}{penalty matrix for the model. Sum of the elements of \code{S.list}}
#' \item{rank.S}{rank of the penalty matrix}
#' \item{S.F}{balanced penalty matrix as described in section 3.1.2 of (Wood,2016). Sum of the elements of \code{S.F.list}}
#' \item{U.F}{Eigen vectors of S.F, useful for the initial reparameterization to separate penalized ad unpenalized subvectors. Allows stable evaluation of the log determinant of S and its derivatives}
#' \item{S.add}{List of penalty matrices associated with all "add" calls}
#' \item{S.tensor}{List of penalty matrices associated with all "tensor" calls}
#' \item{S.tint}{List of penalty matrices associated with all "tint" calls}
#' \item{S.pen}{List of all the rescaled penalty matrices redimensioned to df.tot size. Every element of \code{pen} noted \code{pen[[i]]} is made from a penalty matrix returned by
#' \code{\link{smooth.cons}} and is multiplied by the factor \code{S.scale=norm(X,type="I")^2/norm(pen[[i]],type="I")}}
#' \item{S.list}{Equivalent to S.pen but with every element multiplied by its associated smoothing parameter}
#' \item{S.F.list}{Equivalent to S.pen but with every element divided by its Frobenius norm}
#' \item{lambda}{vector of smoothing parameters}
#' \item{df.para}{degrees of freedom associated with full parametric terms}
#' \item{df.smooth}{degrees of freedom associated with penalized terms}
#' \item{df.tot}{\code{df.para + df.smooth}}
#' \item{list.add}{List of all \code{add.smooth.spec} objects contained in the model}
#' \item{list.tensor}{List of all \code{tensor.smooth.spec} objects contained in the model}
#' \item{list.tint}{List of all \code{tint.smooth.spec} objects contained in the model}
#' \item{nb.smooth}{number of smoothing parameters}
#' \item{Z.add}{List of matrices that represents the sum-to-zero constraints to apply for \code{\link{add}} splines}
#' \item{Z.tensor}{List of matrices that represents the sum-to-zero constraints to apply for \code{\link{tensor}} splines}
#' \item{Z.tint}{List of matrices that represents the sum-to-zero constraints to apply for \code{\link{tint}} splines}
#' @export
#'
model.cons <- function(formula,lambda,data.spec,t1,t1.name,t0,t0.name,event,event.name,expected,expected.name,type,n.legendre,cl){

  #--------------------------------------------
  # extracting information from formula

  formula <- stats::as.formula(formula)
  
  Terms <- stats::terms(formula)
  tmp <- attr(Terms, "term.labels")

  if(attr(Terms, "intercept")==0){

	intercept <- "-1"

  }else{

	intercept <- ""

  }

  if (attr(Terms,"response") > 0) {
    response <- as.character(attr(Terms,"variables")[2])
  } else {
    response <- NULL
  }

  # indices of smooth terms
  ind.add <- grep("add", tmp, fixed = TRUE)

  ind.tensor <- grep("tensor", tmp, fixed = TRUE)

  ind.tint <- grep("tint", tmp, fixed = TRUE)

  # names of smooth terms
  Ad <- tmp[ind.add]
  Tens <- tmp[ind.tensor]
  Tint <- tmp[ind.tint]

  smooth.add <- FALSE
  smooth.tensor <- FALSE
  smooth.tint <- FALSE

  # Are there smooth terms ?
  length.Ad <- length(Ad)
  length.Tens <- length(Tens)
  length.Tint <- length(Tint)

  if (length.Ad!=0) smooth.add <- TRUE
  if (length.Tens!=0) smooth.tensor <- TRUE
  if (length.Tint!=0) smooth.tint <- TRUE

  # full parametric terms
  if (smooth.add | smooth.tensor | smooth.tint){
    Para <- tmp[-c(ind.add,ind.tensor,ind.tint)]
  }else{
    Para <- tmp
  }

  # parametric formula
  if (length(Para)==0){
    formula.para <- stats::as.formula(paste(response,"~1",sep=""))
  }else{
    formula.para <- stats::as.formula(paste(response,"~",paste(Para,collapse="+"),intercept,sep=""))
  }

  # parametric design matrix
  X.para <- stats::model.matrix(formula.para,data=data.spec)

  df.para <- NCOL(X.para)

  # Initialization of smooth matrices
  X.add <- NULL
  X.tensor <- NULL
  X.tint <- NULL

  Z.add <- NULL
  Z.tensor <- NULL
  Z.tint <- NULL

  S.add <- NULL
  S.tensor <- NULL
  S.tint <- NULL

  ##################### If there are additive smooth terms
  if (smooth.add){

    X.add <- vector("list",length.Ad)
    S.add <- vector("list",length.Ad)

	Z.add <- vector("list",length.Ad)
	list.add <- vector("list",length.Ad)
    # We get the design and penalization matrices from the add call(s)
    # (there may be several calls)

	dim.add <- vector(length=length.Ad)
	df.add <- vector(length=length.Ad)

    for (i in 1:length.Ad){

	    list.add[[i]] <- eval(parse(text=Ad[i]))

	    if(list.add[[i]]$dim>1) stop("add calls must contain only one covariate")

		temp <- smooth.cons(list.add[[i]]$term,list.add[[i]]$knots,list.add[[i]]$df,option="add",data.spec)

		X.add[[i]] <- temp$X
		S.add[[i]] <- temp$pen

		Z.add[[i]] <- temp$Z.add
	    list.add[[i]]$knots <- temp$knots

	    dim.add[i] <- list.add[[i]]$dim # How many add calls ?
	    df.add[i] <- list.add[[i]]$df # For each add call, how many degrees of freedom

	    colnames(X.add[[i]]) <- rep(paste(Ad[i],"(",1:NCOL(X.add[[i]]),")",sep=""))
    }

    # We join all design matrices for additive smooths
    X.add <- do.call(cbind, X.add)

  }

  # If there is tensor smooth terms
  if (smooth.tensor){

    X.tensor <- vector("list",length.Tens)
    S.tensor <- vector("list",length.Tens)

	Z.tensor <- vector("list",length.Tens)
	list.tensor <- vector("list",length.Tens)

    dim.tensor <- vector(length=length.Tens)
    df.tensor <- vector(length=length.Tens)

    # We get the design and penalization matrices from the tensor calls
    # (there may be several)
    for (i in 1:length.Tens){

	  list.tensor[[i]] <- eval(parse(text=Tens[i]))

	  temp <- smooth.cons(list.tensor[[i]]$term,list.tensor[[i]]$knots,list.tensor[[i]]$df,option="tensor",data.spec)

      dim.tensor[i] <- list.tensor[[i]]$dim # How many tensor calls ?
      df.tensor[i] <- prod(list.tensor[[i]]$df) # For each tensor call, how many degrees of freedom

      X.tensor[[i]] <- temp$X
      S.tensor[[i]] <- temp$pen

      Z.tensor[[i]] <- temp$Z.tensor
      list.tensor[[i]]$knots <- temp$knots

      colnames(X.tensor[[i]]) <- rep(paste(Tens[i],"(",1:NCOL(X.tensor[[i]]),")",sep=""))
    }

    # We join all design matrices for tensor smooths
    X.tensor <- do.call(cbind, X.tensor)

  }

    ##################### If there is tint smooth terms
  if (smooth.tint){

    X.tint <- vector("list",length.Tint)
    S.tint <- vector("list",length.Tint)

	Z.tint <- vector("list",length.Tint)
	list.tint <- vector("list",length.Tint)

    dim.tint <- vector(length=length.Tint)
    df.tint <- vector(length=length.Tint)

    # We get the design and penalization matrices from the tint calls
    # (there may be several)

    for (i in 1:length.Tint){

  		list.tint[[i]] <- eval(parse(text=Tint[i]))

  		temp <- smooth.cons(list.tint[[i]]$term,list.tint[[i]]$knots,list.tint[[i]]$df,option="tint",data.spec)

  		dim.tint[i] <- list.tint[[i]]$dim # How many tint calls ?
  		df.tint[i] <- prod(list.tint[[i]]$df-1) # For each tint call, how many degrees of freedom

  		X.tint[[i]] <- temp$X
  		S.tint[[i]] <- temp$pen

  		Z.tint[[i]] <- temp$Z.tint # list of matrices
  		list.tint[[i]]$knots <- temp$knots

  		colnames(X.tint[[i]]) <- rep(paste(Tint[i],"(",1:NCOL(X.tint[[i]]),")",sep=""))
    }

    # We join all design matrices for tint smooths
    X.tint <- do.call(cbind, X.tint)

  }

  X.smooth <- cbind(X.add,X.tensor,X.tint)

  X <- cbind(X.para,X.smooth)

  df.tot <- NCOL(X)

  if (smooth.add){
    df.add <- df.add+rep(-1,length.Ad) # we take back 1 df per add call because
    # of the sum-to-zero constraint
  }else{
    dim.add <- 0
    df.add <- 0
	list.add <- NULL
  }

  # Here, length(Tens) may be more than 1
  if (smooth.tensor){
    df.tensor <- df.tensor+rep(-1,length.Tens) # we take back 1 df per tensor call
  }else{
	dim.tensor <- 0
    df.tensor <- 0
	list.tensor <- NULL
  }

  if (smooth.tint){
    df.tint <- df.tint
  }else{
	dim.tint <- 0
    df.tint <- 0
	list.tint <- NULL
  }

  sum.df.add <- sum(df.add)
  sum.df.tensor <- sum(df.tensor)
  sum.df.tint <- sum(df.tint)
  
  sum.dim.add <- sum(dim.add)
  sum.dim.tensor <- sum(dim.tensor)
  sum.dim.tint <- sum(dim.tint)
  
  df.smooth <- sum.df.add+sum.df.tensor+sum.df.tint
  nb.smooth <- sum.dim.add+sum.dim.tensor+sum.dim.tint
  # Define the final penalization matrix
  S <- matrix(0,nrow=df.tot,ncol=df.tot)

  # Define the balanced penalty (see Wood 2016)
  S.F <- matrix(0,nrow=df.tot,ncol=df.tot)

  # List of all the penalization matrices with nrow=df.tot and ncol=df.tot
  S.pen <- lapply(1:nb.smooth, function(i) matrix(0,nrow=df.tot,ncol=df.tot))	
  
  S.list <- lapply(1:nb.smooth, function(i) matrix(0,nrow=df.tot,ncol=df.tot))

  S.F.list <- lapply(1:nb.smooth, function(i) matrix(0,nrow=df.tot,ncol=df.tot))

  # Finally We join all penalization matrices into S if there are any smooths
  if (smooth.add | smooth.tensor | smooth.tint){

	  pen <- lapply(1:nb.smooth, function(i) matrix(0,nrow=df.smooth,ncol=df.smooth))

    # additive matrices
    if (smooth.add){
      for (i in 1:length.Ad){

        df.plus <- if(i==1){0}else{cumsum(df.add)[i-1]}
        dim.plus <- if(i==1){0}else{cumsum(dim.add)[i-1]}

        position.add <- (1+df.plus):(df.add[i]+df.plus)

        for (j in 1:dim.add[i]){

          pen[[j+dim.plus]][position.add,position.add] <- S.add[[i]][[j]]

        }

      }
    }

    # tensor matrices
    if (smooth.tensor){
      for (i in 1:length.Tens){

		df.plus <- if(i==1){0}else{cumsum(df.tensor)[i-1]}
		dim.plus <- if(i==1){0}else{cumsum(dim.tensor)[i-1]}

		position.temp <- sum.df.add+df.plus
		position.tensor <- (position.temp+1):(position.temp+df.tensor[i])

        for (j in 1:dim.tensor[i]){

          pen[[j+sum.dim.add+dim.plus]][position.tensor,position.tensor] <- S.tensor[[i]][[j]]

        }

      }
    }

	# tint matrices
    if (smooth.tint){
      for (i in 1:length.Tint){

		df.plus <- if(i==1){0}else{cumsum(df.tint)[i-1]}
		dim.plus <- if(i==1){0}else{cumsum(dim.tint)[i-1]}

		position.temp <- sum.df.add+sum.df.tensor+df.plus
		position.tint <- (position.temp+1):(position.temp+df.tint[i])

        for (j in 1:dim.tint[i]){

          pen[[j+sum.dim.add+sum.dim.tensor+dim.plus]][position.tint,position.tint] <- S.tint[[i]][[j]]

        }

      }
    }

    if (is.null(lambda)) {lambda <- rep(0,nb.smooth)}

    # All penalty matrices into a unique S

	norm.X <- norm(X,type="I")^2

	for (i in 1:nb.smooth){

		# Rescaling the penalty matrices

		S.scale <- norm.X/norm(pen[[i]],type="I")

		pen[[i]] <- S.scale*pen[[i]]

		S.pen[[i]][(df.para+1):df.tot,(df.para+1):df.tot] <- pen[[i]]
		
	    S.list[[i]] <- lambda[i]*S.pen[[i]]

	    S.F.list[[i]] <- S.pen[[i]]/norm(S.pen[[i]],type="F")

	    S <- S+S.list[[i]]

	    S.F <- S.F+S.F.list[[i]]

    }

	#------------------------------------------------------------------------------- 
	# Initial reparamtrization to separate penalized and unpenalized subvectors
	eigen.F <- eigen(S.F,symmetric=TRUE) 
	U.F <- eigen.F$vectors # eigen vectors of S.F
	vp.F <- eigen.F$values # eigen values of S.F
		
	tol.S.F <- .Machine$double.eps^0.8 * max(vp.F) # see Appendix B of Wood, S. N. (2011) 
	# Fast Stable Restricted Maximum Likelihood and Marginal Likelihood Estimation of 
	# Semiparametric Generalized Linear Models, Journal of the Royal Statistical Society, Series B, 73, 3 36.
		
	pos.S.F.eigen <- vp.F[vp.F >= tol.S.F] # positive eigen values of S.F
	rank.S <- length(pos.S.F.eigen) 

	
  } else {
    
	nb.smooth <- 0
    S.pen <- NULL
	rank.S <- NULL
	U.F <- NULL
	
  }

  #-------------------------------------------------------------------
  # Design matrices for Gauss-Legendre quadrature

  leg <- statmod::gauss.quad(n=n.legendre,kind="legendre")

  X.func <- function(t1,t1.name,data,formula,Z.add,Z.tensor,Z.tint,list.add,list.tensor,list.tint){

    data.t <- data
    data.t[,t1.name] <- t1
    design.matrix(formula,data.spec=data.t,Z.add=Z.add,Z.tensor=Z.tensor,Z.tint=Z.tint,list.add=list.add,list.tensor=list.tensor,list.tint=list.tint)

  }

  tm <- 0.5*(t1-t0)

  # list of n.legendre design matrices for numerical integration
  X.GL <- lapply(1:n.legendre, function(i) X.func(tm*leg$nodes[i]+(t0+t1)/2,t1.name,data.spec,formula,Z.add,Z.tensor,Z.tint,list.add,list.tensor,list.tint))
  
  # List of the transpose design matrices
  T.X.GL <- lapply(1:n.legendre, function(i) t(X.GL[[i]]))

  # List of the weighted design matrices 
  X.GL.w.tm <- lapply(1:n.legendre, function(i) X.GL[[i]]*leg$weights[i]*tm)
  
  # To reduce execution time we do some calculations in advance
  eventX <- event*X
  eventXexpected <- eventX*expected

  return(list(cl=cl,type=type,n.legendre=n.legendre,t0=t0,t0.name=t0.name,t1=t1,t1.name=t1.name,tm=tm,event=event,event.name=event.name,expected=expected,expected.name=expected.name,
  eventX=eventX,eventXexpected=eventXexpected,n=dim(X)[1],p=dim(X)[2],X.para=X.para,X.smooth=X.smooth,X=X,T.X=t(X),leg=leg,X.GL=X.GL,T.X.GL=T.X.GL,X.GL.w.tm=X.GL.w.tm,S=S,rank.S=rank.S,S.F=S.F,U.F=U.F,
  S.add=S.add,S.tensor=S.tensor,S.tint=S.tint,S.pen=S.pen,S.list=S.list,S.F.list=S.F.list,lambda=lambda,df.para=df.para,df.smooth=df.smooth,df.tot=df.tot,
  list.add=list.add,list.tensor=list.tensor,list.tint=list.tint,nb.smooth=nb.smooth,Z.add=Z.add,Z.tensor=Z.tensor,Z.tint=Z.tint))

}

#----------------------------------------------------------------------------------------------------------------
# END of code : model.cons
#----------------------------------------------------------------------------------------------------------------
  
  

#----------------------------------------------------------------------------------------------------------------
# design.matrix : builds the design matrices for numerical integration. The sum-to-zero constraints applied must
# be the ones that were derived in model.cons
#----------------------------------------------------------------------------------------------------------------

#' Design matrix for the model needed in Gauss-Legendre quadrature
#'
#' Builds the design matrix for the whole model when the sum-to-zero constraints are specified. The function is called inside \code{\link{model.cons}}
#' for Gauss-Legendre quadrature.
#'
#' @param formula formula object identifying the model
#' @param data.spec data frame that represents the environment from which the covariate values and knots are to be calculated
#' @param Z.add List of matrices that represents the sum-to-zero constraint to apply for \code{\link{add}} splines
#' @param Z.tensor List of matrices that represents the sum-to-zero constraint to apply for \code{\link{tensor}} splines
#' @param Z.tint List of matrices that represents the sum-to-zero constraint to apply for \code{\link{tint}} splines
#' @param list.add List of all add.smooth.spec objects contained in the model
#' @param list.tensor List of all tensor.smooth.spec objects contained in the model
#' @param list.tint List of all tint.smooth.spec objects contained in the model
#' @return design matrix for the model
#' @export
#'
design.matrix <- function(formula,data.spec,Z.add,Z.tensor,Z.tint,list.add,list.tensor,list.tint){

  formula <- stats::as.formula(formula)

  Terms <- stats::terms(formula)
  tmp <- attr(Terms, "term.labels")

  if(attr(Terms, "intercept")==0){

	intercept <- "-1"

  }else{

	intercept <- ""

  }

  if (attr(Terms,"response") > 0) {
    response <- as.character(attr(Terms,"variables")[2])
  } else {
    response <- NULL
  }

  # indices of smooth terms
  ind.add <- grep("add", tmp, fixed = TRUE)

  ind.tensor <- grep("tensor", tmp, fixed = TRUE)

  ind.tint <- grep("tint", tmp, fixed = TRUE)

  # names of smooth terms
  Ad <- tmp[ind.add]
  Tens <- tmp[ind.tensor]
  Tint <- tmp[ind.tint]

  smooth.add <- FALSE
  smooth.tensor <- FALSE
  smooth.tint <- FALSE

  # Are there smooth terms ?
  length.Ad <- length(Ad)
  length.Tens <- length(Tens)
  length.Tint <- length(Tint)

  if (length.Ad!=0) smooth.add <- TRUE
  if (length.Tens!=0) smooth.tensor <- TRUE
  if (length.Tint!=0) smooth.tint <- TRUE

  # full parametric terms
  if (smooth.add | smooth.tensor | smooth.tint){
    Para <- tmp[-c(ind.add,ind.tensor,ind.tint)]
  }else{
    Para <- tmp
  }

  # parametric formula
  if (length(Para)==0){
    formula.para <- stats::as.formula(paste(response,"~1",sep=""))
  }else{
    formula.para <- stats::as.formula(paste(response,"~",paste(Para,collapse="+"),intercept,sep=""))

  }

  # parametric design matrix
  X.para <- stats::model.matrix(formula.para,data=data.spec)

  df.para <- NCOL(X.para)

  # Initialization of smooth matrices
  X.add <- NULL
  X.tensor <- NULL
  X.tint <- NULL

  ##################### If there are additive smooth terms
  if (smooth.add){

    X.add <- vector("list",length.Ad)

    # We get the design matrix from the add call
    # (there should be only one call)

    for (i in 1:length.Ad){ # here we must have length.Ad=1

      X.add[[i]] <- smooth.cons.integral(list.add[[i]]$term,list.add[[i]]$knots,list.add[[i]]$df,option="add",data.spec,Z.add=Z.add[[i]],Z.tensor=NULL,Z.tint=NULL)
      colnames(X.add[[i]]) <- rep(paste(Ad[i],"(",1:NCOL(X.add[[i]]),")",sep=""))

    }

    # We join all design matrices for additive smooths
    X.add <- do.call(cbind, X.add)

  }

  # If there is tensor smooth terms
  if (smooth.tensor){

    X.tensor <- vector("list",length.Tens)

    # We get the design from the tensor calls
    # (there may be several)

    for (i in 1:length.Tens){

      X.tensor[[i]] <- smooth.cons.integral(list.tensor[[i]]$term,list.tensor[[i]]$knots,list.tensor[[i]]$df,option="tensor",data.spec,Z.add=NULL,Z.tensor=Z.tensor[[i]],Z.tint=NULL)
      colnames(X.tensor[[i]]) <- rep(paste(Tens[i],"(",1:NCOL(X.tensor[[i]]),")",sep=""))

    }

    # We join all design matrices for tensor smooths
    X.tensor <- do.call(cbind, X.tensor)

  }

    ##################### If there is tint smooth terms
  if (smooth.tint){

    X.tint <- vector("list",length.Tint)

    # We get the design from the tint calls
    # (there may be several)

    for (i in 1:length.Tint){

      X.tint[[i]] <- smooth.cons.integral(list.tint[[i]]$term,list.tint[[i]]$knots,list.tint[[i]]$df,option="tint",data.spec,Z.add=NULL,Z.tensor=NULL,Z.tint=Z.tint[[i]])
      colnames(X.tint[[i]]) <- rep(paste(Tint[i],"(",1:NCOL(X.tint[[i]]),")",sep=""))

    }

    # We join all design matrices for tint smooths
    X.tint <- do.call(cbind, X.tint)

  }

  X.smooth <- cbind(X.add,X.tensor,X.tint)

  X <- cbind(X.para,X.smooth)

  return(X)

}
#----------------------------------------------------------------------------------------------------------------
# END of code : design.matrix
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# Initial reparameterization : 
#----------------------------------------------------------------------------------------------------------------

#' Applies initial reparameterization for stable evaluation of the log determinant of the penalty matrix
#'
#' Transforms the object from \code{\link{model.cons}} by applying the matrix reparameterization (matrix U.F). The reparameterization
#' is reversed at convergence by \code{\link{inv.repam}}.
#'
#' @param build object as returned by \code{\link{model.cons}}
#' @return 
#' \item{build}{an object as returned by \code{\link{model.cons}}}
#' \item{X.ini}{initial design matrix (before reparameterization)}
#' \item{S.pen.ini}{initial penalty matrices}
#' @export
#'
repam <- function(build){
	
	coef.name <- colnames(build$X)
	
	# We store X and S to given them back at convegence
	X.ini <- build$X
	S.pen.ini <- build$S.pen
	#--------
	
	build$X <- build$X%*%build$U.F
	
	colnames(build$X) <- coef.name
	
	build$T.X <- t(build$X)
	
	build$S.pen <- lapply(1:build$nb.smooth,function(i) t(build$U.F)%*%build$S.pen[[i]]%*%build$U.F)
	build$S.pen <- lapply(1:build$nb.smooth,function(i) 0.5*(t(build$S.pen[[i]])+build$S.pen[[i]]))

	build$S.list <- lapply(1:build$nb.smooth,function(i) build$lambda[i]*build$S.pen[[i]])
	build$S <- Reduce("+",build$S.list)
	# List of the transpose design matrices
			
	build$X.GL <- lapply(1:build$n.legendre, function(i) build$X.GL[[i]]%*%build$U.F)
	build$T.X.GL <- lapply(1:build$n.legendre, function(i) t(build$X.GL[[i]]))

	# List of the weighted design matrices 
	build$X.GL.w.tm <- lapply(1:build$n.legendre, function(i) build$X.GL[[i]]*build$leg$weights[i]*build$tm)
			  
	# To reduce execution time we do some calculations in advance
	build$eventX <- build$event*build$X
	build$eventXexpected <- build$eventX*build$expected
	
	return(list(build=build,X.ini=X.ini,S.pen.ini=S.pen.ini))
						
}
#----------------------------------------------------------------------------------------------------------------
# END of code : repam
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# Return to standard parameterization : 
#----------------------------------------------------------------------------------------------------------------

#' Reverses initial reparameterization for stable evaluation of the log determinant of the penalty matrix
#'
#' Transforms the final model by reversing the initial reparameterization performed by \code{\link{repam}}. Derives the corrected version of the Bayesian covariance matrix 
#'
#' @param model survPen object, see \code{\link{survPen.fit}} for details
#' @param X.ini initial design matrix (before reparameterization)
#' @param S.pen.ini initial penalty matrices
#' @return survPen object with standard parameterization
#' @export
#'
inv.repam <- function(model,X.ini,S.pen.ini){
	
	U <- model$U.F
	T.U <- t(U)
	
	coef.name <- colnames(model$X)
	
	model$beta.hat <- as.vector(U%*%model$beta.hat)
	model$X <- X.ini
	model$S.pen <- S.pen.ini
	model$S.list <- lapply(1:model$nb.smooth,function(i) model$lambda[i]*model$S.pen[[i]])
	model$S <- Reduce("+",model$S.list)

	model$grad.unpen.beta <- model$grad.unpen.beta%*%T.U
	model$grad.beta <- model$grad.beta%*%T.U
	model$Hess.unpen.beta <- U%*%model$Hess.unpen.beta%*%T.U
	model$Hess.beta <- U%*%model$Hess.beta%*%T.U
	model$VarF <- U%*%model$VarF%*%T.U
	model$VarF <- 0.5*(model$VarF + t(model$VarF)) # to be sure VarF is symmetric
	
	model$VarB <- U%*%model$VarB%*%T.U
	
	rownames(model$VarB) <- colnames(model$VarB) <- rownames(model$VarF) <- colnames(model$VarF) <-
	colnames(model$X) <- names(model$beta.hat) <- coef.name
	
	optim.rho <- !is.null(model$optim.rho)
	
	if (optim.rho){
	
		model$deriv.rho.inv.Hess.beta <- lapply(1:model$nb.smooth,function(i) U%*%model$deriv.rho.inv.Hess.beta[[i]]%*%T.U)
		model$deriv.rho.beta <- model$deriv.rho.beta%*%T.U
		
	}
	
	if (model$criterion=="LAML" & optim.rho){
		#---------------------------------------------------------------------------------------------------------
		# for corrected variance, we need the derivative of R wrt smooting parameters with t(R)%*%R=VarB
		deriv.VarB <- vector("list", model$nb.smooth)

		deriv.R1 <- vector("list", model$nb.smooth)

		B <- vector("list", model$nb.smooth)

		R1 <- chol(model$VarB)
		p <- model$p
		
		inv.R1 <- backsolve(R1, diag(model$p))

		for (m in 1:model$nb.smooth){

			deriv.VarB[[m]] <- -(model$deriv.rho.inv.Hess.beta[[m]])

			deriv.R1[[m]] <- matrix(0,p,p)

			B <- deriv.VarB[[m]]

			for (i in 1:p){
				for (j in i:p){# R and its derivatives are triangular superior

					if((i-1)>0){

						for (k in 1:(i-1)){

							B[i,j] <- B[i,j]-(deriv.R1[[m]][k,i]*R1[k,j]+R1[k,i]*deriv.R1[[m]][k,j])

						}

					}

					if(i==j){

						deriv.R1[[m]][i,j] <- 0.5*B[i,j]/R1[i,j]

					}else{

						deriv.R1[[m]][i,j] <- 1/R1[i,i]*(B[i,j]-R1[i,j]*deriv.R1[[m]][i,i])
					}

				}

			}

							
		}
	
		model$deriv.R1 <- deriv.R1
	
		# regularization of the inverse Hessian when a smoothing parameter tends to infinity

		if (any(abs(diag(model$Hess.rho))<1e-04)){
			eigen.cor<-eigen(model$Hess.rho,symmetric=TRUE)
			U.cor<-eigen.cor$vectors
			vp.cor<-eigen.cor$values

			if (length(vp.cor)!=1){

				inv.Hess.rho<-U.cor%*%diag(1/(vp.cor+0.02))%*%t(U.cor)

			}else{

				inv.Hess.rho<-U.cor/(vp.cor+0.02)*U.cor

			}

		}else{
		
			inv.Hess.rho <- model$inv.Hess.rho
		
		}
	
		V.second <- matrix(0,p,p)

		for (l in 1:model$nb.smooth){

			for (k in 1:model$nb.smooth){

				prod.temp <- crossprod(deriv.R1[[k]],deriv.R1[[l]])*inv.Hess.rho[k,l]
				
				V.second <- V.second+prod.temp
				
			}

		}

		#---------------------------------------------------------------------------------------------------------

		# corrected variance (for smoothing parameter uncertainty), Kass and Steffey approximation
		VarC.approx <- model$VarB+t(model$deriv.rho.beta)%*%(inv.Hess.rho)%*%model$deriv.rho.beta

		# full corrected variance
		VarC <- VarC.approx+V.second
			
		rownames(VarC.approx) <- colnames(VarC.approx) <- rownames(VarC) <- colnames(VarC) <- coef.name
			
		model$VarC.approx <- VarC.approx
		model$VarC <- VarC
			
		# corrected AIC
		edf.cor<-sum(-model$Hess.unpen*model$VarC)
			
		model$aicc <- -2*model$ll+2*edf.cor
		
	}
	
	return(model)

}
#----------------------------------------------------------------------------------------------------------------
# END of code : inv.repam
#----------------------------------------------------------------------------------------------------------------




#----------------------------------------------------------------------------------------------------------------
# survPen : fits a multidimensionnal penalized survival model on the logarithm of the (excess) hazard
# This function estimates automatically the smoohting parameters via NR.rho and calls survPen.fit for
# estimation of the betas
#----------------------------------------------------------------------------------------------------------------

#' (Excess) hazard model with multidimensional penalized splines and integrated smoothness estimation
#'
#' Fits an (excess) hazard model with multidimensional penalized splines in order to take into
#' account time-dependent and non linear effects of covariates. The linear predictor is specified on the logarithm of the hazard. Smooth terms are represented using
#' cubic regression splines. For multidimensional smooths, tensor product splines or tensor product interactions
#' are available. Smoothness is estimated automatically by optimizing one of two criteria: Laplace approximate marginal likelihood (LAML) or likelihood cross-validation (LCV).
#' Any parametric formula can be specified for the (excess) hazard model. No distinction is made between the part relative to the form of the baseline hazard and the one relative
#' to the effects of the covariates.
#' Thus, time-dependent effects are naturally specified as interactions with some function of time via "*" or ":". See the examples below for more details.
#'
#' @param formula formula object specifying the model. Smooth terms are specified using \code{\link{add}} (equivalent to \code{s(...,bs="cr")} in \code{mgcv}),
#' \code{\link{tensor}} (equivalent to \code{te(...,bs="cr")} in \code{mgcv}) or \code{\link{tint}} (equivalent to \code{ti(...,bs="cr")} in \code{mgcv}).
#' @param data an optional data frame containing the variables in the model
#' @param t1 vector of follow-up times or name of the column in \code{data} containing follow-up times
#' @param t0 vector of origin times or name of the column in \code{data} containing origin times; allows to take into account left truncation; default is NULL, in which case it will be a vector of zeros
#' @param event vector of right-censoring indicators or name of the column in \code{data} containing right-censoring indicators; 1 if the event occurred and 0 otherwise
#' @param expected (for net survival only) vector of expected hazard or name of the column in \code{data} containing expected hazard; default is NULL, in which case overall survival will be estimated
#' @param lambda vector of smoothing parameters; default is NULL when it is to be estimated by LAML or LCV
#' @param rho.ini vector of initial log smoothing parameters; default is NULL, in which case every initial log lambda will be -1
#' @param max.it.beta maximum number of iterations to reach convergence in the regression coefficients; default is 200
#' @param max.it.rho maximum number of iterations to reach convergence in the smoothing parameters; default is 30
#' @param beta.ini vector of initial regression coefficients; default is NULL, in which case the first beta will be \code{log(sum(event)/sum(t1))} and the others will be zero
#' @param detail.rho if TRUE, details concerning the optimization process in the smoothing parameters are displayed; default is FALSE
#' @param detail.beta if TRUE, details concerning the optimization process in the regression coefficients are displayed; default is FALSE
#' @param n.legendre number of Gauss-Legendre quadrature nodes to be used to compute the cumulative hazard; default is 15
#' @param criterion criterion used to select the smoothing parameters. Should be "LAML" or "LCV"; default is "LAML"
#' @param type kind of model that is to be fitted. Should be "net" for excess hzard model (net survival) and "overall" for standard hazard model (overall survival); default is "overall"
#' @param tol.beta convergence tolerance for regression coefficients; default is \code{1e-04}. See \code{\link{NR.beta}} for details
#' @param tol.rho convergence tolerance for smoothing parameters; default is \code{1e-04}. See \code{\link{NR.rho}} for details
#' @param step.max maximum absolute value possible for any component of the step vector (on the log smoothing parameter scale) in LCV or LAML optimization; default is 5
#' @return Object of class "survPen" (see \code{\link{survPen.fit}} for details)
#' @export
#'
#' @details
#' In time-to-event analysis, we may deal with one or several continuous covariates whose functional forms and time-dependent effects are challenging. 
#' Wood et al. (2016) provided a general penalized framework that made available smooth function estimation to a wide variety of models, including the Cox proportional hazard model. 
#' They proposed to estimate smoothing parameters by maximizing a Laplace approximate marginal likelihood (LAML) criterion and demonstrate how statistical consistency is maintained by doing so.
#' The function \code{\link{survPen}} implements the framework described by Wood et al. (2016) for modeling time-to-event data when the effects of covariates on the log-hazard scale may depend on unknown smooth functions.
#' This framework allows to account simultaneously for time-dependent and nonlinear effects without the need to build a possibly demanding modeling strategy.
#' Besides LAML, \code{\link{survPen}} allows to use a likelihood cross-validation (LCV) criterion (Verweij and Van Houwelingen 1993) for smoothing parameter estimation.
#' First and second derivatives of the LCV criterion with respect to the smoothing parameters are implemented so that LCV optimization is computationally equivalent to the LAML optimization proposed by Wood et al. (2016).
#' In practice, LAML optimization is generally both a bit faster and a bit more stable so it is used as default. 
#' For \eqn{m} covariates \eqn{(x_1,\ldots,x_m)}, if we note \eqn{h(t,x_1,\ldots,x_m)} the hazard at time \eqn{t}, the hazard model is the following :
#' \deqn{log(h(t,x_1,\ldots,x_m))=f(t,x_1,\ldots,x_m)}
#'
#' where \eqn{f} is an unknown multidimensional function. The marginal bases of the covariates are represented
#' as penalized natural cubic splines with associated quadratic penalties.
#' The estimation procedure is based on outer Newton-Raphson iterations for the smoothing parameters and on inner Newton-Raphson iterations for the regression coefficients (see Wood et al. 2016).
#' Estimation of the regression coefficients in the inner algorithm is by direct maximization of the penalized likelihood of the survival model, therefore avoiding data augmentation and Poisson likelihood approximation. 
#' The cumulative hazard included in the log-likelihood is approximated by Gauss-Legendre quadrature for numerical stability.
#'
#' When studying the survival of patients who suffer from a common pathology we may be interested in the concept of excess mortality that represents the mortality due to that pathology. 
#' For example, in cancer epidemiology, individuals may die from cancer or from another cause. The problem is that the cause of death is often either unavailable or unreliable. 
#' Supposing that the mortality due to other causes may be obtained from the total mortality of the general population (called expected mortality for cancer patients), we can define the concept of excess mortality. 
#' The excess mortality is directly linked to the concept of net survival, which would be the observed survival if patients could not die from other causes. Therefore, when such competing events are present, 
#' one may choose to fit an excess hazard model instead of a classical hazard model. Flexible excess hazard models have already been proposed (for examples see Remontet et al. 2007, Charvat et al. 2016) but, to my knowledge, none of them deal with a penalized framework.
#' Excess mortality can be estimated supposing that, in patients suffering from a common pathology, mortality due to others causes than the pathology can be obtained from the (all cause) mortality of the general population; the latter is referred to as the expected mortality \eqn{h_P}. 
#' Then, the excess mortality hazard due to the pathology (\eqn{h_E}), the quantity of interest, may be obtained by subtracting \eqn{h_P} from the mortality observed in the patients (\eqn{h_O}). This may be written as:
#' \deqn{h_E(t,x)=h_O(t,x)-h_P(a+t,z)}
#' In that equation, \eqn{t} is the time since cancer diagnosis, \eqn{a} is the age at diagnosis, \eqn{h_P} is the mortality of the general population at age \eqn{a+t} given demographical characteristics \eqn{z} (\eqn{h_P} is considered known and available from national statistics), 
#' and \eqn{x} a vector of variables that may have an effect on \eqn{h_E}. Including the age in the model is necessary in order to deal with the informative censoring due to other causes of death. 
#' Thus, for \eqn{m} covariates \eqn{(x_1,\ldots,x_m)}, if we note \eqn{h_E(t,x_1,\ldots,x_m)} the excess hazard at time \eqn{t}, the excess hazard model is the following :
#' \deqn{log(h_E(t,x_1,\ldots,x_m))=f(t,x_1,\ldots,x_m)}
#'
#' If convergence issues occur, don't refrain to use detail.rho and/or detail.beta to see exactly what is going on in the optimization process. To achieve convergence, consider lowering step.max or increasing tol.beta and tol.rho.
#'
#' @references
#' Charvat, H., Remontet, L., Bossard, N., Roche, L., Dejardin, O., Rachet, B., ... and Belot, A. (2016), A multilevel excess hazard model to estimate net survival on hierarchical data allowing for non linear and non proportional effects of covariates. Statistics in medicine, 35(18), 3066-3084. \cr \cr
#' Remontet, L., Bossard, N., Belot, A., & Esteve, J. (2007), An overall strategy based on regression models to estimate relative survival and model the effects of prognostic factors in cancer survival studies. Statistics in medicine, 26(10), 2214-2228. \cr \cr
#' Verweij, P. J., and Van Houwelingen, H. C. (1993), Cross validation in survival analysis. Statistics in medicine, 12(24), 2305-2314. \cr \cr
#' Wood, S.N., N. Pya and B. Saefken (2016), Smoothing parameter and model selection for general smooth models (with discussion). Journal of the American Statistical Association 111, 1548-1575
#'
#' @examples
#' library(survPen)
#' data(datCancer) # simulated dataset with 2000 individuals diagnosed with cervical cancer
#' 
#' #-------------------------------------------------------- example 1
#' # hazard models with fully parametric formulas compared to a penalized tensor product smooth
#'
#' # constant hazard model
#' f.cst <- ~1
#' mod.cst <- survPen(f.cst,data=datCancer,t1=fu,event=dead)
#'
#' # linear effect of time
#' f.lin <- ~fu
#' mod.lin <- survPen(f.lin,data=datCancer,t1=fu,event=dead)
#'
#' # linear effect of time and age
#' f.lin.age <- ~fu+age
#' mod.lin.age <- survPen(f.lin.age,data=datCancer,t1=fu,event=dead)
#'
#' # linear effect of time and age with time-dependent effect of age (linear)
#' f.lin.inter.age <- ~fu*age
#' mod.lin.inter.age <- survPen(f.lin.inter.age,data=datCancer,t1=fu,event=dead)
#'
#' # cubic B-spline of time with a knot at 1 year, linear effect of age and time-dependent effect
#' # of age with a quadratic B-spline of time with a knot at 1 year
#' library(splines)
#' f.spline.inter.age <- ~bs(fu,knots=c(1),Boundary.knots=c(0,5))+age+
#' age:bs(fu,knots=c(1),Boundary.knots=c(0,5),degree=2)
#' mod.spline.inter.age <- survPen(f.spline.inter.age,data=datCancer,t1=fu,event=dead)
#'
#'
#' # tensor of time and age
#' f.tensor <- ~tensor(fu,age)
#' mod.tensor <- survPen(f.tensor,data=datCancer,t1=fu,event=dead)
#'
#'
#' # predictions of the hazard versus for age 60
#'
#' new.time <- seq(0,5,length=50)
#' pred.cst <- predict(mod.cst,data.frame(fu=new.time))
#' pred.lin <- predict(mod.lin,data.frame(fu=new.time))
#' pred.lin.age <- predict(mod.lin.age,data.frame(fu=new.time,age=60))
#' pred.lin.inter.age <- predict(mod.lin.inter.age,data.frame(fu=new.time,age=60))
#' pred.spline.inter.age <- predict(mod.spline.inter.age,data.frame(fu=new.time,age=60))
#' pred.tensor <- predict(mod.tensor,data.frame(fu=new.time,age=60))
#' 
#' par(mfrow=c(1,1))
#' plot(new.time,pred.cst$haz,type="l",ylim=c(0,0.2),main="hazard vs time",
#' xlab="years since diagnosis",ylab="hazard",col="blue3")
#' lines(new.time,pred.lin$haz,col="green3")
#' lines(new.time,pred.lin.age$haz,col="yellow")
#' lines(new.time,pred.lin.inter.age$haz,col="orange")
#' lines(new.time,pred.spline.inter.age$haz,col="red")
#' lines(new.time,pred.tensor$haz,col="black")
#' legend("topright",legend=c("cst","lin","lin.age","lin.inter.age","spline.inter.age","tensor"),
#' col=c("blue3","green3","yellow","orange","red","black"),lty=rep(1,6))
#'
#'
#' #-------------------------------------------------------- example 2
#' 
#' # model : unidimensional penalized spline for time since diagnosis with 5 knots
#' f1 <- ~add(fu,df=5)
#' 
#' # you can specify your own knots if you want
#' # f1 <- ~add(fu,knots=c(0,1,3,6,8))
#' 
#' # hazard model
#' mod1 <- survPen(f1,data=datCancer,t1=fu,event=dead,expected=NULL,criterion="LAML")
#' summary(mod1)
#' 
#' # to see where the knots were placed
#' mod1$list.add
#' 
#' # with LCV instead of LAML
#' mod1bis <- survPen(f1,data=datCancer,t1=fu,event=dead,expected=NULL,criterion="LCV")
#' summary(mod1bis)
#' 
#' # hazard model taking into account left truncation (not representative of cancer data, 
#' # the begin variable was simulated for illustration purposes only)
#' mod2 <- survPen(f1,data=datCancer,t0=begin,t1=fu,event=dead,expected=NULL,criterion="LAML")
#' summary(mod2)
#' 
#' # excess hazard model
#' mod3 <- survPen(f1,data=datCancer,t1=fu,event=dead,expected=rate,type="net",criterion="LAML")
#' summary(mod3)
#' 
#' 
#' # compare the predictions of the models
#' new.time <- seq(0,5,length=50)
#' pred1 <- predict(mod1,data.frame(fu=new.time))
#' pred1bis <- predict(mod1bis,data.frame(fu=new.time))
#' pred2 <- predict(mod2,data.frame(fu=new.time))
#' pred3 <- predict(mod3,data.frame(fu=new.time))
#' 
#' 
#' 
#' # LAML vs LCV
#' par(mfrow=c(1,2))
#' plot(new.time,pred1$haz,type="l",ylim=c(0,0.2),main="LCV vs LAML",
#' xlab="years since diagnosis",ylab="hazard")
#' lines(new.time,pred1bis$haz,col="blue3")
#' legend("topright",legend=c("LAML","LCV"),col=c("black","blue3"),lty=c(1,1))
#' 
#' plot(new.time,pred1$surv,type="l",ylim=c(0,1),main="LCV vs LAML",
#' xlab="years since diagnosis",ylab="survival")
#' lines(new.time,pred1bis$surv,col="blue3")
#' 
#' 
#' # no truncation vs truncation
#' par(mfrow=c(1,2))
#' plot(new.time,pred1$haz,type="l",ylim=c(0,0.2),main="no truncation vs truncation",
#' xlab="years since diagnosis",ylab="hazard")
#' lines(new.time,pred2$haz,col="red")
#' legend("topright",legend=c("no trunc","trunc"),col=c("black","red"),lty=c(1,1))
#' 
#' plot(new.time,pred1$surv,type="l",ylim=c(0,1),main="no truncation vs truncation",
#' xlab="years since diagnosis",ylab="survival")
#' lines(new.time,pred2$surv,col="red")
#' 
#' 
#' # hazard vs excess hazard
#' par(mfrow=c(1,2))
#' plot(new.time,pred1$haz,type="l",ylim=c(0,0.2),main="hazard vs excess hazard",
#' xlab="years since diagnosis",ylab="hazard")
#' lines(new.time,pred3$haz,col="green3")
#' legend("topright",legend=c("overall","excess"),col=c("black","green3"),lty=c(1,1))
#' 
#' plot(new.time,pred1$surv,type="l",ylim=c(0,1),main="survival vs net survival",
#' xlab="time",ylab="survival")
#' lines(new.time,pred3$surv,col="green3")
#' 
#' # hazard vs excess hazard with 95% Bayesian confidence intervals
#' par(mfrow=c(1,1))
#' plot(new.time,pred1$haz,type="l",ylim=c(0,0.2),main="hazard vs excess hazard",
#' xlab="years since diagnosis",ylab="hazard")
#' lines(new.time,pred3$haz,col="green3")
#' legend("topright",legend=c("overall","excess"),col=c("black","green3"),lty=c(1,1))
#' 
#' lines(new.time,pred1$haz.inf,lty=2)
#' lines(new.time,pred1$haz.sup,lty=2)
#' 
#' lines(new.time,pred3$haz.inf,lty=2,col="green3")
#' lines(new.time,pred3$haz.sup,lty=2,col="green3")
#' 
#' 
#' #-------------------------------------------------------- example 3
#' 
#' # models : tensor product smooths vs tensor product interactions of time since diagnosis and 
#' # age at diagnosis. Smoothing parameters are estimated via LAML maximization
#' f2 <- ~tensor(fu,age,df=c(5,5))
#' 
#' f3 <- ~tint(fu,df=5)+tint(age,df=5)+tint(fu,age,df=c(5,5))
#' 
#' # hazard model
#' mod4 <- survPen(f2,data=datCancer,t1=fu,event=dead)
#' summary(mod4)
#' 
#' mod5 <- survPen(f3,data=datCancer,t1=fu,event=dead)
#' summary(mod5)
#' 
#' # predictions
#' new.age <- seq(50,90,length=50)
#' new.time <- seq(0,7,length=50)
#' 
#' Z4 <- outer(new.time,new.age,function(t,a) predict(mod4,data.frame(fu=t,age=a))$haz)
#' Z5 <- outer(new.time,new.age,function(t,a) predict(mod5,data.frame(fu=t,age=a))$haz)
#' 
#' # color settings
#' col.pal <- colorRampPalette(c("white", "red"))
#' colors <- col.pal(100)
#' 
#' facet <- function(z){
#' 
#' 	facet.center <- (z[-1, -1] + z[-1, -ncol(z)] + z[-nrow(z), -1] + z[-nrow(z), -ncol(z)])/4
#' 	cut(facet.center, 100)
#' 	
#' }
#' 
#' # plot the hazard surfaces for both models
#' par(mfrow=c(1,2))
#' persp(new.time,new.age,Z4,col=colors[facet(Z4)],main="tensor",theta=30,
#' xlab="years since diagnosis",ylab="age at diagnosis",zlab="excess hazard",ticktype="detailed")
#' persp(new.time,new.age,Z5,col=colors[facet(Z5)],main="tint",theta=30,
#' xlab="years since diagnosis",ylab="age at diagnosis",zlab="excess hazard",ticktype="detailed")
#' 
#' #-------------------------------------------------------- example 4
#' 
#' # model : tensor product spline for time, age and yod (year of diagnosis)
#' f4 <- ~tensor(fu,age,yod,df=c(5,5,5))
#' 
#' # excess hazard model taking into account left truncation
#' mod6 <- survPen(f4,data=datCancer,t0=begin,t1=fu,event=dead,expected=rate,type="net")
#' summary(mod6)
#' 
#' 
#' # predictions of the surfaces for ages 50, 60, 70 and 80
#' new.year <- seq(1990,2010,length=30)
#' new.time <- seq(0,5,length=50)
#' 
#' Z_50 <- outer(new.time,new.year,function(t,y) predict(mod6,data.frame(fu=t,yod=y,age=50))$haz)
#' Z_60 <- outer(new.time,new.year,function(t,y) predict(mod6,data.frame(fu=t,yod=y,age=60))$haz)
#' Z_70 <- outer(new.time,new.year,function(t,y) predict(mod6,data.frame(fu=t,yod=y,age=70))$haz)
#' Z_80 <- outer(new.time,new.year,function(t,y) predict(mod6,data.frame(fu=t,yod=y,age=80))$haz)
#' 
#' 
#' # plot the hazard surfaces for a given age
#' par(mfrow=c(2,2))
#' persp(new.time,new.year,Z_50,col=colors[facet(Z_50)],main="age 50",theta=20,
#' xlab="years since diagnosis",ylab="yod",zlab="excess hazard",ticktype="detailed")
#' persp(new.time,new.year,Z_60,col=colors[facet(Z_60)],main="age 60",theta=20,
#' xlab="years since diagnosis",ylab="yod",zlab="excess hazard",ticktype="detailed")
#' persp(new.time,new.year,Z_70,col=colors[facet(Z_70)],main="age 70",theta=20,
#' xlab="years since diagnosis",ylab="yod",zlab="excess hazard",ticktype="detailed")
#' persp(new.time,new.year,Z_80,col=colors[facet(Z_80)],main="age 80",theta=20,
#' xlab="years since diagnosis",ylab="yod",zlab="excess hazard",ticktype="detailed")
#' 
#' ########################################
#' 
survPen <- function(formula,data,t1,t0=NULL,event,expected=NULL,lambda=NULL,rho.ini=NULL,max.it.beta=200,max.it.rho=30,beta.ini=NULL,detail.rho=FALSE,detail.beta=FALSE,n.legendre=20,criterion="LAML",type="overall",tol.beta=1e-04,tol.rho=1e-04,step.max=5){

	cl <- match.call()

	if (missing(formula) | missing(data) | missing(t1) | missing(event)) stop("Must have at least a formula, data, t1 and event arguments")

	formula <- stats::as.formula(formula)
	
	if (!(criterion %in% c("LAML","LCV"))) stop("criterion should be LAML or LCV")
	if (!(type %in% c("overall","net"))) stop("type should be overall or net")

	t1.name <- deparse(substitute(t1))
	t1 <- eval(substitute(t1), data)

	if (!is.numeric(t1)) stop("t1 variable is not numeric")

	n <- length(t1)

	t0.name <- deparse(substitute(t0))
	t0 <- eval(substitute(t0), data)

	event.name <- deparse(substitute(event))
	event <- eval(substitute(event), data)

	expected.name <- deparse(substitute(expected))
	expected <- eval(substitute(expected), data)

	if (is.null(expected) & type=="net"){
		warning("no expected mortality, overall survival is estimated")
		type <- "overall"
	}

	if (!is.null(expected) & type=="overall"){
		warning("expected mortality found, net survival is estimated")
		type <- "net"
	}

	if (is.null(t0)) t0 <- rep(0,n)
	if (is.null(event)) event <- rep(1,n)
	if (is.null(expected)) expected <- rep(0,n)

	if (length(t0) != n) stop("t0 and t1 are different lengths")
	if (length(event) != n) stop("event and t1 are different lengths")
	if (length(expected) != n) stop("expected and t1 are different lengths")

	build <- model.cons(formula,lambda,data,t1,t1.name,t0,t0.name,event,event.name,expected,expected.name,type,n.legendre,cl)
		
	if (is.null(lambda)){

		nb.smooth <- build$nb.smooth

		if(nb.smooth!=0){ # Are there any penalized terms ?

			if (is.null(rho.ini)) rho.ini <- rep(-1,nb.smooth) # initial values for log(lambda)
		
			# Initial reparametrization
			param <- repam(build)
			build <- param$build
			X.ini <- param$X.ini
			S.pen.ini <- param$S.pen.ini
			
			# smoothing parameters are to be selected, optimization of LCV or LAML criterion
			model <- NR.rho(build,rho.ini=rho.ini,data=data,formula=formula,max.it.beta=max.it.beta,max.it.rho=max.it.rho,beta.ini=beta.ini,
			detail.rho=detail.rho,detail.beta=detail.beta,nb.smooth=nb.smooth,tol.beta=tol.beta,tol.rho=tol.rho,step.max=step.max,criterion=criterion)

			# Inversion of initial reparametrization
			model <- inv.repam(model, X.ini, S.pen.ini)
			
			return(model)

		}else{

			# only fully parametric terms in the model so no need for smoothing parameter selection
			build$lambda <- 0

			survPen.fit(build,data=data,formula=formula,max.it.beta=max.it.beta,beta.ini=beta.ini,detail.beta=detail.beta,criterion=criterion,tol.beta=tol.beta)

		  }

	}else{

		# Initial reparametrization
		param <- repam(build)
		build <- param$build
		X.ini <- param$X.ini
		S.pen.ini <- param$S.pen.ini
	
		# smoothing parameters are given by the user so no need for smoothing parameter selection
		model <- survPen.fit(build,data=data,formula=formula,max.it.beta=max.it.beta,beta.ini=beta.ini,detail.beta=detail.beta,criterion=criterion,tol.beta=tol.beta)

		# Inversion of initial reparametrization
		model <- inv.repam(model, X.ini, S.pen.ini)
		
		return(model)
		
	}

}

#----------------------------------------------------------------------------------------------------------------
# END of code : survPen
#----------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------
# survPen.fit : fits a multidimensionnal penalized survival model on the logarithm of the (excess) hazard
# The smoohting parameters must be specified
#----------------------------------------------------------------------------------------------------------------


#' (Excess) hazard model with multidimensional penalized splines for given smoothing parameters
#'
#' Fits an (excess) hazard model. If penalized splines are present, the smoothing parameters are specified.
#' @param build list of objects returned by \code{\link{model.cons}}
#' @param data an optional data frame containing the variables in the model
#' @param formula formula object specifying the model
#' @param max.it.beta maximum number of iterations to reach convergence in the regression coefficients; default is 200
#' @param beta.ini vector of initial regression coefficients; default is NULL, in which case the first beta will be \code{log(sum(event)/sum(t1))} and the others will be zero
#' @param detail.beta if TRUE, details concerning the optimization process in the regression coefficients are displayed; default is FALSE
#' @param criterion criterion used to select the smoothing parameters. Should be "LAML" or "LCV"; default is "LAML"
#' @param tol.beta convergence tolerance for regression coefficients; default is \code{1e-04}. See \code{\link{NR.beta}} for details
#' @return Object of class "survPen"
#' \item{call}{original \code{survPen} call}
#' \item{formula}{formula object specifying the model}
#' \item{t0.name}{name of the vector of origin times}
#' \item{t1.name}{name of the vector of follow-up times}
#' \item{event.name}{name of the vector of right-censoring indicators}
#' \item{expected.name}{name of the vector of expected hazard}
#' \item{haz}{fitted hazard}
#' \item{beta.hat}{estimated regression coefficients}
#' \item{type}{"net" or "overall"}
#' \item{df.para}{degrees of freedom associated with full parametric terms}
#' \item{df.smooth}{degrees of freedom associated with penalized terms}
#' \item{p}{number of parameters}
#' \item{edf}{effective degrees of freedom}
#' \item{edf.cor}{effective degrees of freedom corrected for smoothing parameter uncertainty}
#' \item{aic}{Akaike information criterion with number of parameters replaced by edf when there are penalized terms. Corresponds to 2*edf - 2*ll.unpen}
#' \item{aicc}{Akaike information criterion corrected for smoothing parameters uncertainty}
#' \item{iter.beta}{vector of numbers of iterations needed to estimate the regression coefficients for each smoothing parameters trial. It thus contains \code{iter.rho+1} elements.}
#' \item{X}{design matrix of the model}
#' \item{S}{penalty matrix of the model}
#' \item{S.list}{Equivalent to pen but with every element multiplied by its associated smoothing parameter}
#' \item{S.pen}{List of all the rescaled penalty matrices redimensioned to df.tot size. Every element of \code{pen} noted \code{pen[[i]]} is made from a penalty matrix returned by
#' \code{\link{smooth.cons}} and is multiplied by the factor \code{S.scale=norm(X,type="I")^2/norm(pen[[i]],type="I")}}
#' \item{grad.unpen.beta}{gradient vector of the log-likelihood with respect to the regression coefficients}
#' \item{grad.beta}{gradient vector of the penalized log-likelihood with respect to the regression coefficients}
#' \item{Hess.unpen.beta}{hessian vector of the log-likelihood with respect to the regression coefficients}
#' \item{Hess.beta}{hessian of the penalized log-likelihood with respect to the regression coefficients}
#' \item{Hess.beta.modif}{if TRUE, the hessian of the penalized log-likelihood has been perturbed at convergence}
#' \item{ll.unpen}{log-likelihood at convergence}
#' \item{ll}{penalized log-likelihood at convergence}
#' \item{deriv.rho.beta}{transpose of the Jacobian of beta with respect to the log smoothing parameters}
#' \item{deriv.rho.inv.Hess.beta}{list containing the derivatives of the inverse of \code{Hess} with respect to the log smoothing parameters}
#' \item{deriv.rho.Hess.unpen.beta}{list containing the derivatives of \code{Hess.unpen} with respect to the log smoothing parameters}
#' \item{lambda}{estimated smoothing parameters}
#' \item{nb.smooth}{number of smoothing parameters}
#' \item{iter.rho}{number of iterations needed to estimate the smoothing parameters}
#' \item{optim.rho}{identify whether the smoothing parameters were estimated or not; 1 when exiting the function \code{\link{NR.rho}}; default is NULL}
#' \item{criterion}{criterion used for smoothing parameter estimation}
#' \item{criterion.val}{value of the criterion used for smoothing parameter estimation at convergence}
#' \item{LCV}{Likelihood cross-validation criterion at convergence}
#' \item{LAML}{minus Laplace approximate marginal likelihood at convergence}
#' \item{grad.rho}{gradient vector of criterion with respect to the log smoothing parameters}
#' \item{Hess.rho}{hessian matrix of criterion with respect to the log smoothing parameters}
#' \item{inv.Hess.rho}{inverse of \code{Hess.rho}}
#' \item{Hess.rho.modif}{if TRUE, the hessian of LCV or LAML has been perturbed at convergence}
#' \item{VarF}{Frequentist covariance matrix}
#' \item{VarB}{Bayesian covariance matrix}
#' \item{VarC}{Bayesian covariance matrix corrected for smoothing parameters uncertainty}
#' \item{VarC.approx}{Kass and Steffey approximation of \code{VarC} (see (Wood,2016))}
#' \item{Z.add}{List of matrices that represents the sum-to-zero constraint to apply for \code{\link{add}} splines}
#' \item{Z.tensor}{List of matrices that represents the sum-to-zero constraint to apply for \code{\link{tensor}} splines}
#' \item{Z.tint}{List of matrices that represents the sum-to-zero constraint to apply for \code{\link{tint}} splines}
#' \item{list.add}{List of all \code{add.smooth.spec} objects contained in the model}
#' \item{list.tensor}{List of all \code{tensor.smooth.spec} objects contained in the model}
#' \item{list.tint}{List of all \code{tint.smooth.spec} objects contained in the model}
#' \item{converged}{if FALSE, convergence could not be reached for either the regression coefficients or the smoothing parameters}
#' \item{U.F}{Eigen vectors of S.F, useful for the initial reparameterization to separate penalized ad unpenalized subvectors. Allows stable evaluation of the log determinant of S and its derivatives}
#' @export
#'
survPen.fit <- function(build,data,formula,max.it.beta=200,beta.ini=NULL,detail.beta=FALSE,criterion="LAML",tol.beta=1e-04)
{
  # collecting information from the formula (design matrix, penalty matrices, ...)
  formula <- stats::as.formula(formula)
  
  cl <- build$cl

  n <- build$n
  X <- build$X
  T.X <- build$T.X

  S <- build$S
  lambda <- build$lambda
  rank.S <- build$rank.S
  S.list <- build$S.list
  S.F <- build$S.F
  S.F.list <- build$S.F.list
  U.F <- build$U.F
  # number of parameters
  p <- build$p

  # number of unpenalized parameters
  df.para <- build$df.para
  # number of penalized parameters
  df.smooth <- build$df.smooth

  # We get the penalized terms with their knots and degrees of freedom
  list.add <- build$list.add

  list.tensor <- build$list.tensor

  list.tint <- build$list.tint

  # number of smoothing parameters
  nb.smooth <- build$nb.smooth

  t0 <- build$t0
  t1 <- build$t1
  tm <- build$tm
  event <- build$event
  expected <- build$expected

  type <- build$type

  eventX <- build$eventX
  eventXexpected <- build$eventXexpected

  Z.add <- build$Z.add
  Z.tensor <- build$Z.tensor
  Z.tint <- build$Z.tint

  leg <- build$leg
  n.legendre <- build$n.legendre
  X.GL <- build$X.GL
  T.X.GL <- build$T.X.GL
  X.GL.w.tm <- build$X.GL.w.tm
  #-------------------------------------------------------------------
  # Optimization algorithm : Newton-Raphson

  # Initialization of beta.ini is very important
  # All betas except intercept will be initialized to zero
  # intercept will be initialized to log(sum(event)/sum(t1))

  if (is.null(beta.ini)) {beta.ini=c(log(sum(event)/sum(t1)),rep(0,df.para+df.smooth-1))}

  Algo.optim <- NR.beta(build,beta.ini,detail.beta=detail.beta,max.it.beta=max.it.beta,tol.beta=tol.beta)

  # Estimations and likelihoods
  beta.hat <- Algo.optim$beta.hat
  names(beta.hat) <- colnames(X)
  ll.unpen <- Algo.optim$ll.unpen
  ll <- Algo.optim$ll
  haz.GL <- Algo.optim$haz.GL
  iter.beta <- Algo.optim$iter.beta
  #-------------------------------------------------------------------

  # fitted (excess) hazard
  pred1=as.vector(X%*%beta.hat)
  ft1=as.vector(exp(pred1))

  #-------------------------------------------------------------------
  # Gradient and Hessian at convergence

  deriv.list <- lapply(1:n.legendre, function(i) X.GL.w.tm[[i]]*haz.GL[[i]])

  deriv.2.list <- lapply(1:n.legendre, function(i) T.X.GL[[i]]%*%(deriv.list[[i]]))

  f.first <- Reduce("+",deriv.list)

  # gradient
  if (type=="net"){
	  grad.unpen.beta <- colSums(-f.first + (eventX*ft1)/(ft1+expected))
  }else{
	  grad.unpen.beta <- colSums(-f.first + eventX)
  }

  grad.beta <- grad.unpen.beta-as.vector(S%*%beta.hat)

  # Hessian

  f.second <- Reduce("+",deriv.2.list)

  if (type=="net"){
	Hess.unpen.beta <- -f.second + T.X%*%(eventXexpected*ft1/(ft1+expected)^2)
  }else{
	Hess.unpen.beta <- -f.second
  }

  Hess.beta <- Hess.unpen.beta-S

  minus.Hess.beta <- -Hess.beta

  R <- try(chol(minus.Hess.beta),silent=TRUE)

  Hess.beta.modif <- FALSE

  converged=TRUE
  # Hessian perturbation if necessary (should not be the case at convergence though)
  if(class(R)=="Error"|class(R)=="try-error")
	{
		Hess.beta.modif <- TRUE
		converged <- FALSE
		eigen.temp <- eigen(minus.Hess.beta,symmetric=TRUE)
		U.temp <- eigen.temp$vectors
		vp.temp <- eigen.temp$values

		vp.temp[which(vp.temp<1e-7)] <- 1e-7

		R <- try(chol(U.temp%*%diag(vp.temp)%*%t(U.temp)),silent=TRUE)

		warning("beta Hessian was perturbed at convergence")
	}

  minus.inv.Hess.beta <- chol2inv(R)

  inv.Hess.beta <- -minus.inv.Hess.beta

  minus.Hess.beta <- t(R)%*%R
  Hess.beta <- -minus.Hess.beta

  # Variance
  VarF <- -inv.Hess.beta%*%Hess.unpen.beta%*%inv.Hess.beta # frequentist variance
  VarB <- minus.inv.Hess.beta # Bayesian variance
  
  rownames(VarF) <- colnames(VarF) <- rownames(VarB) <- colnames(VarB) <- colnames(X)
  #-------------------------------------------------------------------

#------------------------------------------------------------------------
#------------------------------------------------------------------------
# Smoothing parameters selection
#------------------------------------------------------------------------
#------------------------------------------------------------------------

if(nb.smooth!=0){

	#------------------------------------------------------------------------
	# LCV criteria
	#------------------------------------------------------------------------

	# effective degrees of freedom
	edf <- sum(Hess.unpen.beta*inv.Hess.beta)

	# LCV
	LCV <- -ll.unpen+edf

	#------------------------------------------------------------------------
	# LAML criteria
	#------------------------------------------------------------------------

	if (sum(lambda)<.Machine$double.eps) {

		log.abs.S <- 0
		M.p <- 0
		sub.S <- S[1:rank.S,1:rank.S]
		
	}else{
	
		M.p <- p-rank.S
		sub.S <- S[1:rank.S,1:rank.S]
		qr.S <- qr(sub.S)
		log.abs.S <- sum(log(abs(diag(qr.S$qr))))

	}

	log.det.Hess.beta <- as.numeric(2*determinant(R,logarithm=TRUE)$modulus)

	# this is actually -LAML so that we can minimize it
	LAML <- -(ll+0.5*log.abs.S-0.5*log.det.Hess.beta+0.5*M.p*log(2*pi))

	#------------------------------------------------------------------------
	# derivatives of LCV and LAML with respect to the smoothing parameters
	#------------------------------------------------------------------------

	if (sum(lambda)>.Machine$double.eps) {
	
		S.beta <- lapply(1:nb.smooth,function(i) S.list[[i]]%*%beta.hat)
		
		deriv.rho.beta <- matrix(0,nrow=nb.smooth,ncol=p)
		GL.temp <- vector("list",nb.smooth)
		
		for (i in 1:nb.smooth){

			deriv.rho.beta[i,] <- inv.Hess.beta%*%S.beta[[i]]

			GL.temp[[i]] <- lapply(1:n.legendre, function(j) as.vector((X.GL[[j]]%*%deriv.rho.beta[i,])*haz.GL[[j]]))
			
		}
			
		if(criterion=="LCV"){

			criterion.val <- LCV
		
			# this calculation is done before to save time
			mat.temp <- inv.Hess.beta+VarF

			# gradient of LCV

			grad.rho.edf <- vector(length=nb.smooth)
			deriv.rho.Hess.unpen.beta <- vector("list", nb.smooth)
			deriv.rho.inv.Hess.beta <- vector("list", nb.smooth)

			if (type=="net"){
				temp2.matrix2 <- (X*ft1*(-ft1+expected)/(ft1+expected)^3)
			}

			# first derivatives of beta Hessian

			for (j in 1:nb.smooth){

				f.third <- matrix(0,nrow=p,ncol=p)

				for (i in 1:n.legendre){

					f.third <- f.third+T.X.GL[[i]]%*%(X.GL.w.tm[[i]]*GL.temp[[j]][[i]])

					}

				if (type=="net"){
					deriv.rho.Hess.unpen.beta[[j]] <- (-f.third) + T.X%*%(eventXexpected*as.vector(temp2.matrix2%*%deriv.rho.beta[j,]))
				}else{
					deriv.rho.Hess.unpen.beta[[j]] <- (-f.third)
				}

				deriv.rho.inv.Hess.beta[[j]] <- -inv.Hess.beta%*%(deriv.rho.Hess.unpen.beta[[j]]-S.list[[j]])%*%inv.Hess.beta

				# gradient of edf
				grad.rho.edf[j] <- sum(mat.temp*deriv.rho.Hess.unpen.beta[[j]])+sum(-VarF*S.list[[j]])

			}

			grad.LCV1 <- as.vector(deriv.rho.beta%*%(-grad.unpen.beta))
			grad.rho <- grad.LCV1+grad.rho.edf

			deriv2.rho.beta <- lapply(1:nb.smooth, function(i) matrix(0,nrow=nb.smooth,ncol=p))

			for (j in 1:nb.smooth){

				for (j2 in 1:nb.smooth){

					deriv2.rho.beta[[j2]][j,] <- deriv.rho.inv.Hess.beta[[j2]]%*%S.beta[[j]]+
					inv.Hess.beta%*%(S.list[[j]]%*%deriv.rho.beta[j2,])

					if (j==j2){

					deriv2.rho.beta[[j2]][j,] <- deriv2.rho.beta[[j2]][j,]+inv.Hess.beta%*%S.beta[[j2]]

					}

				}

			}

			Hess.LCV1 <- matrix(0,nb.smooth,nb.smooth)

			# first part of the Hessian of LCV
			for (j2 in 1:nb.smooth){

				Hess.LCV1[,j2] <- deriv2.rho.beta[[j2]]%*%(-grad.unpen.beta)+deriv.rho.beta%*%(-Hess.unpen.beta%*%deriv.rho.beta[j2,])

			}

			# this calculation is done before to save time

			deriv.rho.VarF <- lapply(1:nb.smooth, function(j2) -(  (deriv.rho.inv.Hess.beta[[j2]]%*%Hess.unpen.beta+
			inv.Hess.beta%*%deriv.rho.Hess.unpen.beta[[j2]] )%*%inv.Hess.beta +  inv.Hess.beta%*%Hess.unpen.beta%*%deriv.rho.inv.Hess.beta[[j2]])  )

			deriv.mat.temp <- lapply(1:nb.smooth, function(j2) deriv.rho.VarF[[j2]]+deriv.rho.inv.Hess.beta[[j2]] )

			# Hessian of LCV

			Hess.edf <- matrix(0,nb.smooth,nb.smooth)

			if (type=="net"){
				temp2.matrix1 <- (X*ft1*(ft1^2-4*expected*ft1+expected^2)/(ft1+expected)^4)
			}

			# second derivatives of the coef Hessian
			for (j in 1:nb.smooth){

				for (j2 in 1:nb.smooth){

					f.fourth <- matrix(0,nrow=p,ncol=p)

					for (i in 1:n.legendre){

						temp <- (X.GL[[i]]*GL.temp[[j2]][[i]])%*%deriv.rho.beta[j,]+
						as.vector((X.GL[[i]]*haz.GL[[i]])%*%deriv2.rho.beta[[j2]][j,])

						f.fourth <- f.fourth+T.X.GL[[i]]%*%(X.GL.w.tm[[i]]*as.vector(temp))

					}

					if (type=="net"){

						temp2 <- as.vector((X*as.vector(temp2.matrix1%*%deriv.rho.beta[j2,]))%*%deriv.rho.beta[j,])+
						as.vector(temp2.matrix2%*%deriv2.rho.beta[[j2]][j,])

						deriv2.rho.Hess.unpen.beta <- (-f.fourth) + T.X%*%(eventXexpected*as.vector(temp2))

					}else{

						deriv2.rho.Hess.unpen.beta <- (-f.fourth)

					}

					# Hessian of edf

					Hess.edf[j,j2] <- sum(mat.temp*deriv2.rho.Hess.unpen.beta)+
					sum(deriv.mat.temp[[j2]]*deriv.rho.Hess.unpen.beta[[j]])+sum(-deriv.rho.VarF[[j2]]*S.list[[j]])

					if (j==j2){

						Hess.edf[j,j2] <- Hess.edf[j,j2]+sum(-VarF*S.list[[j2]])

					}

				}

			}

			Hess.rho <- Hess.LCV1+Hess.edf

		}

		#------------------------------------------------------------------------
		# derivatives of LAML
		#------------------------------------------------------------------------

		if(criterion=="LAML"){

			criterion.val <- LAML
			
			inverse.new.S <- solve(sub.S) # stable LU decomposition

			temp.LAML <- lapply(1:nb.smooth,function(i) S.list[[i]][1:rank.S,1:rank.S])

			# gradient of LAML

			grad.rho.log.det.Hess.beta <- vector(length=nb.smooth)
			grad.rho.log.abs.S <- vector(length=nb.smooth)
			deriv.rho.Hess.unpen.beta <- vector("list", nb.smooth)
			deriv.rho.inv.Hess.beta <- vector("list", nb.smooth)
			grad.rho.ll1 <- vector(length=nb.smooth)
			
			# this calculation is done before to save time
			if (type=="net"){
				temp2.matrix2 <- (X*ft1*(-ft1+expected)/(ft1+expected)^3)
			}

			# first derivatives of Hess.beta
			for (j in 1:nb.smooth){

				f.third <- matrix(0,nrow=p,ncol=p)

				for (i in 1:n.legendre){
					
					f.third <- f.third+T.X.GL[[i]]%*%(X.GL.w.tm[[i]]*GL.temp[[j]][[i]])

				}

				if (type=="net"){
					deriv.rho.Hess.unpen.beta[[j]] <- (-f.third) + T.X%*%(eventXexpected*as.vector(temp2.matrix2%*%deriv.rho.beta[j,]))
				}else{
					deriv.rho.Hess.unpen.beta[[j]] <- (-f.third)
				}

				deriv.rho.inv.Hess.beta[[j]] <- -inv.Hess.beta%*%(deriv.rho.Hess.unpen.beta[[j]]-S.list[[j]])%*%inv.Hess.beta

				grad.rho.log.det.Hess.beta[j] <- sum(-inv.Hess.beta*(-deriv.rho.Hess.unpen.beta[[j]]+S.list[[j]]))

				grad.rho.log.abs.S[j] <- sum(inverse.new.S*temp.LAML[[j]])

				grad.rho.ll1[j] <- -0.5*as.numeric(t(beta.hat)%*%S.beta[[j]])

			}

			grad.rho <- -(grad.rho.ll1+0.5*grad.rho.log.abs.S-0.5*grad.rho.log.det.Hess.beta)

			deriv2.rho.beta <- lapply(1:nb.smooth, function(i) matrix(0,nrow=nb.smooth,ncol=p))

			for (j in 1:nb.smooth){

				for (j2 in 1:nb.smooth){

					deriv2.rho.beta[[j2]][j,] <- deriv.rho.inv.Hess.beta[[j2]]%*%S.beta[[j]]+
					inv.Hess.beta%*%(S.list[[j]]%*%deriv.rho.beta[j2,])

					if (j==j2){

					deriv2.rho.beta[[j2]][j,] <- deriv2.rho.beta[[j2]][j,]+inv.Hess.beta%*%S.beta[[j2]]

					}

				}

			}

			# this calculation is done before to save time
			temp.LAML3 <- lapply(1:nb.smooth,function(i) -inverse.new.S%*%temp.LAML[[i]]%*%inverse.new.S)
			
			# second derivatives of LAML

			Hess.rho.log.det.Hess.beta <- matrix(0,nb.smooth,nb.smooth)

			Hess.rho.log.abs.S <- matrix(0,nb.smooth,nb.smooth)

			Hess.rho.ll1 <- matrix(0,nb.smooth,nb.smooth)

			if (type=="net"){
				temp2.matrix1 <- (X*ft1*(ft1^2-4*expected*ft1+expected^2)/(ft1+expected)^4)
			}
			# second derivatives of the coef Hessian

			for (j in 1:nb.smooth){

				for (j2 in 1:nb.smooth){

					f.fourth <- matrix(0,nrow=p,ncol=p)

					for (i in 1:n.legendre){

						temp <- (X.GL[[i]]*GL.temp[[j2]][[i]])%*%deriv.rho.beta[j,]+
						as.vector((X.GL[[i]]*haz.GL[[i]])%*%deriv2.rho.beta[[j2]][j,])

						f.fourth <- f.fourth+T.X.GL[[i]]%*%(X.GL.w.tm[[i]]*as.vector(temp))

					}

					if (type=="net"){

						temp2 <- as.vector((X*as.vector(temp2.matrix1%*%deriv.rho.beta[j2,]))%*%deriv.rho.beta[j,])+
						as.vector(temp2.matrix2%*%deriv2.rho.beta[[j2]][j,])

						deriv2.Hess.unpen.beta <- (-f.fourth) + T.X%*%(eventXexpected*as.vector(temp2))

					}else{

						deriv2.Hess.unpen.beta <- (-f.fourth)

					}

					Hess.rho.log.det.Hess.beta[j,j2] <- sum(-deriv.rho.inv.Hess.beta[[j2]]*(-deriv.rho.Hess.unpen.beta[[j]]+S.list[[j]]))+
					sum(-inv.Hess.beta*(-deriv2.Hess.unpen.beta))

					Hess.rho.log.abs.S[j,j2] <- sum(temp.LAML3[[j2]]*temp.LAML[[j]])

					Hess.rho.ll1[j,j2] <- -as.numeric(deriv.rho.beta[j2,]%*%S.beta[[j]])

					if (j==j2){

						Hess.rho.log.det.Hess.beta[j,j2] <- Hess.rho.log.det.Hess.beta[j,j2]+sum(-inv.Hess.beta*S.list[[j2]])

						Hess.rho.log.abs.S[j,j2] <- Hess.rho.log.abs.S[j,j2]+sum(inverse.new.S*temp.LAML[[j2]])

						Hess.rho.ll1[j,j2] <- Hess.rho.ll1[j,j2]-0.5*as.numeric(t(beta.hat)%*%S.beta[[j2]])

					}

				}

			}

			Hess.rho <- -(Hess.rho.ll1+0.5*Hess.rho.log.abs.S-0.5*Hess.rho.log.det.Hess.beta)

		}

	}else{
	
		criterion.val=NULL
	
		grad.rho <- NULL
		Hess.rho <- NULL

		deriv.rho.beta <- NULL
		deriv.rho.inv.Hess.beta <- NULL
	
	}
		
}else{

	edf <- p

	criterion.val=NULL
	LCV <- NULL
	LAML <- NULL

	grad.rho <- NULL
	Hess.rho <- NULL

	deriv.rho.beta <- NULL
	deriv.rho.inv.Hess.beta <- NULL

}

	optim.rho <- NULL
	iter.rho <- NULL
	aicc <- NULL
	inv.Hess.rho <- NULL
	Hess.rho.modif <- NULL
	VarC.approx <- NULL
	VarC <- NULL

	# returns a model of class survPen
	res <- list(call=cl,formula=formula,t0.name=build$t0.name,t1.name=build$t1.name,event.name=build$event.name,expected.name=build$expected.name,
	haz=ft1,beta.hat=beta.hat,type=type,df.para=df.para,df.smooth=df.smooth,p=p,edf=edf,aic=2*edf-2*ll.unpen,aicc=aicc,iter.beta=iter.beta,X=X,S=S,
	S.list=S.list,S.pen=build$S.pen,grad.unpen.beta=grad.unpen.beta,grad.beta=grad.beta,Hess.unpen.beta=Hess.unpen.beta,Hess.beta=Hess.beta,
	Hess.beta.modif=Hess.beta.modif,ll.unpen=ll.unpen,ll=ll,deriv.rho.beta=deriv.rho.beta,deriv.rho.inv.Hess.beta=deriv.rho.inv.Hess.beta,lambda=lambda,
	nb.smooth=nb.smooth,iter.rho=iter.rho,optim.rho=optim.rho,criterion=criterion,criterion.val=criterion.val,LCV=LCV,LAML=LAML,grad.rho=grad.rho,Hess.rho=Hess.rho,inv.Hess.rho=inv.Hess.rho,
	Hess.rho.modif=Hess.rho.modif,VarF=VarF,VarB=VarB,VarC=VarC,VarC.approx=VarC.approx,Z.add=Z.add,Z.tensor=Z.tensor,Z.tint=Z.tint,
	list.add=list.add,list.tensor=list.tensor,list.tint=list.tint,converged=converged,U.F=U.F)

	class(res) <- "survPen"
	res
}

#----------------------------------------------------------------------------------------------------------------
# END of code : survPen.fit
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# predict.survPen : makes hazard and survival predictions from a model for a new dataframe
#----------------------------------------------------------------------------------------------------------------

#' Survival prediction from fitted \code{survPen} model
#'
#' Takes a fitted \code{survPen} object and produces hazard and survival predictions given a new set of values for the model covariates.
#' @param object a fitted \code{survPen} object as produced by \code{\link{survPen.fit}}
#' @param newdata data frame giving the new covariates value
#' @param n.legendre number of nodes to approximate the cumulative hazard by Gauss-Legendre quadrature; default is 50
#' @param conf.int numeric value giving the precision of the confidence intervals; default is 0.95
#' @param do.surv If TRUE, the survival and its lower and upper confidence values are computed. Survival computation requires numerical integration and can be time-consuming so if you only want the hazard use do.surv=FALSE; default is TRUE
#' @param ... other arguments
#' @details
#' The confidence intervals noted CI.U are built on the log cumulative hazard scale U=log(H) (efficient scale in terms of respect towards the normality assumption)
#' using Delta method. The confidence intervals on the survival scale are then \code{CI.surv = exp(-exp(CI.U))}
#' @return List of objects:
#' \item{haz}{hazard predicted by the model}
#' \item{haz.inf}{lower value for the confidence interval on the hazard based on VarB}
#' \item{haz.sup}{Upper value for the confidence interval on the hazard based on VarB}
#' \item{surv}{survival predicted by the model}
#' \item{surv.inf}{lower value for the confidence interval on the survival based on VarB}
#' \item{surv.sup}{Upper value for the confidence interval on the survival based on VarB}
#' @export
#'
predict.survPen <- function(object,newdata,n.legendre=50,conf.int=0.95,do.surv=TRUE,...){

	if (!inherits(object,"survPen")) stop("object is not of class survPen")

	qt.norm <- stats::qnorm(1-(1-conf.int)/2)

	t1 <- newdata[,object$t1.name]

	t0 <- rep(0,length(t1))

	tm <- (t1-t0)/2

	leg <- statmod::gauss.quad(n=n.legendre,kind="legendre")

	beta.hat <- object$beta.hat

	myMat <- design.matrix(object$formula,data.spec=newdata,Z.add=object$Z.add,Z.tensor=object$Z.tensor,Z.tint=object$Z.tint,list.add=object$list.add,list.tensor=object$list.tensor,list.tint=object$list.tint)

	pred.haz <- as.vector(myMat%*%object$beta.hat)

	haz <- as.vector(exp(pred.haz))

	if (do.surv){
		# Design matrices for Gauss-Legendre quadrature
		X.func <- function(t1,data,object){

			data.t <- data
			data.t[,object$t1.name] <- t1
			design.matrix(object$formula,data.spec=data.t,Z.add=object$Z.add,Z.tensor=object$Z.tensor,Z.tint=object$Z.tint,list.add=object$list.add,list.tensor=object$list.tensor,list.tint=object$list.tint)

		}

		X.GL <- lapply(1:n.legendre, function(i) X.func(tm*leg$nodes[i]+(t0+t1)/2,newdata,object))

		cumul.haz <- lapply(1:n.legendre, function(i) as.vector(exp((X.GL[[i]]%*%beta.hat)))*leg$weights[i])

		cumul.haz <- tm*Reduce("+",cumul.haz)

		surv=exp(-cumul.haz)

	}else{
	
		surv=NULL
	
	}

	if (!is.null(object$VarB)){ # only Bayesian covariance matrix is used for confidence intervals

		# confidence intervals for hazard
		std <- sqrt(rowSums((myMat%*%object$VarB)*myMat))
		haz.inf <- as.vector(exp(pred.haz-qt.norm*std))
		haz.sup <- as.vector(exp(pred.haz+qt.norm*std))

		if (do.surv){
			# if any cumul hazard is zero, we put it at a very low positive value
			cumul.haz[cumul.haz==0] <- 1e-16

			deriv.cumul.haz <- lapply(1:n.legendre, function(i) X.GL[[i]]*as.vector(exp((X.GL[[i]]%*%beta.hat)))*leg$weights[i])

			deriv.cumul.haz <- tm*Reduce("+",deriv.cumul.haz)

			#---------------------------
			log.cumul.haz <- log(cumul.haz)

			deriv.log.cumul.haz <- deriv.cumul.haz/cumul.haz

			#---------------------------
			# Delta method

			std.log.cumul <- sqrt(rowSums((deriv.log.cumul.haz%*%object$VarB)*deriv.log.cumul.haz))

			surv.inf=exp(-exp(log.cumul.haz+qt.norm*std.log.cumul))
			surv.sup=exp(-exp(log.cumul.haz-qt.norm*std.log.cumul))
			
		}else{
		
			surv.inf=NULL
			surv.sup=NULL
		
		}

	}else{

		haz.inf=NULL
		haz.sup=NULL
		surv.inf=NULL
		surv.sup=NULL

	}

	
	res<-list(haz=haz,haz.inf=haz.inf,haz.sup=haz.sup,
	     surv=surv,surv.inf=surv.inf,surv.sup=surv.sup)

	class(res) <- "predict.survPen"
	
	res	 
}

#----------------------------------------------------------------------------------------------------------------
# END of code : predict.survPen
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# summary.survPen
#----------------------------------------------------------------------------------------------------------------

#' Summary for a \code{survPen} fit
#'
#' Takes a fitted \code{survPen} object and produces various useful summaries from it.
#' @param object a fitted \code{survPen} object as produced by \code{\link{survPen.fit}}
#' @param ... other arguments
#' @return List of objects:
#' \item{call}{the original survPen call}
#' \item{formula}{the original survPen formula}
#' \item{coefficients}{if there are only full parametric terms in the formula, reports the regression coefficients estimates with the associated standard errors}
#' \item{likelihood}{unpenalized likelihood of the model}
#' \item{penalized.likelihood}{penalized likelihood of the model}
#' \item{nb.smooth}{number of smoothing parameters}
#' \item{smoothing.parameter}{smoothing parameters estimates}
#' \item{parameters}{number of regression parameters}
#' \item{edf}{effective degrees of freedom}
#' \item{criterion}{smoothing selection criterion used (LAML or LCV)}
#' \item{val.criterion}{minimized value of criterion. For LAML, what is reported is the negative log marginal likelihood}
#' @export
#'
summary.survPen <- function(object,...){

	if (!inherits(object,"survPen")) stop("object is not of class survPen")

	if(object$type=="net"){

		type <- "excess hazard model"

	}else{

		type <- "hazard model"

	}
	
	# standard errors
	if (object$p==1){
	
		SE <- sqrt(object$VarB)
	
	}else{
	
		SE <- sqrt(diag(object$VarB))
	
	}
	
	len <- object$df.para
	
	TAB <- cbind(object$beta.hat[1:len],SE[1:len])
	colnames(TAB) <- c("Coef","SE")
	

	
	res <- list(type = type,
			call=object$call,
			formula=object$formula,
			coefficients=TAB,
			likelihood = object$ll.unpen,
			penalized.likelihood = object$ll,
			nb.smooth = object$nb.smooth,
			smoothing.parameter = object$lambda,
			parameters = object$p,
			edf = object$edf,
			criterion = object$criterion,
			val.criterion = object$criterion.val)
	
	class(res) <- "summary.survPen"
	
	res
	
}

#----------------------------------------------------------------------------------------------------------------
# END of code : summary.survPen
#----------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------
# NR.beta : Newton-Raphson algotihm for regression coef estimation
#----------------------------------------------------------------------------------------------------------------

#' Inner Newton-Raphson algorithm for regression coefficients estimation
#'
#' Applies Newton-Raphson algorithm for beta estimation. Two specific modifications aims at guaranteeing
#' convergence : first the hessian is perturbed whenever it is not positive definite and second, at each step, if the penalized
#' log-likelihood is not maximized, the step is halved until it is.
#' @param build list of objects returned by \code{\link{model.cons}}
#' @param beta.ini vector of initial regression coefficients; default is NULL, in which case the first beta will be \code{log(sum(event)/sum(t1))} and the others will be zero
#' @param detail.beta if TRUE, details concerning the optimization process in the regression coefficients are displayed; default is FALSE
#' @param max.it.beta maximum number of iterations to reach convergence in the regression coefficients; default is 200
#' @param tol.beta convergence tolerance for regression coefficients; default is \code{1e-04}
#'
#' @details
#' If we note \code{ll} and \code{beta} respectively the current penalized log-likelihood and estimated coefficients and
#' \code{llold} and \code{betaold} the previous ones, the algorithm goes on
#' \code{while(abs(ll-llold)>tol.beta|any(abs((beta-betaold)/betaold)>tol.beta))}
#'
#' @return List of objects:
#' \item{beta.hat}{estimated regression coefficients}
#' \item{ll.unpen}{log-likelihood at convergence}
#' \item{ll}{penalized log-likelihood at convergence}
#' \item{haz.GL}{list of all the matrix-vector multiplications X.GL[[i]]\%*\%beta.hat for Gauss Legendre integration. Useful to avoid repeating operations in \code{\link{survPen.fit}}}
#' \item{iter.beta}{number of iterations needed to converge}
#' @export
#'
NR.beta <- function(build,beta.ini,detail.beta,max.it.beta=200,tol.beta=1e-04){

  type <- build$type
  X <- build$X
  T.X <- build$T.X
  X.GL <- build$X.GL
  T.X.GL <- build$T.X.GL
  X.GL.w.tm <- build$X.GL.w.tm
  event <- build$event
  eventX <- build$eventX
  expected <- build$expected
  eventXexpected <- build$eventXexpected
  leg <- build$leg
  n.legendre <- build$n.legendre
  t1 <- build$t1
  t0 <- build$t0
  tm <- build$tm
  S <- build$S
  p <- build$p

  k=1
  ll=100
  llold=1

  betaold <- beta.ini
  beta1 <- betaold

  # beginning of the while loop
  while(abs(ll-llold)>tol.beta|any(abs((beta1-betaold)/betaold)>tol.beta))
  {

    if(k > max.it.beta)
    {
      stop("message NR.beta: Ran out of iterations (", k, "), and did not converge ")

    }

    if(k>=2)
    {
      llold=ll
      betaold <- beta1
    }

	# hazard
	predold=as.vector(X%*%betaold)
	ftold=as.vector(exp(predold))

	# first derivatives of the cumulative hazard
	haz.GL.old <- lapply(1:n.legendre, function(i) as.vector(exp((X.GL[[i]]%*%betaold))))
	
	deriv.list <- lapply(1:n.legendre, function(i) X.GL.w.tm[[i]]*haz.GL.old[[i]])

	f.first <- Reduce("+",deriv.list)

	# log-likelihoods gradients
	if (type=="net"){
		grad.unpen.beta <- colSums(-f.first + (eventX*ftold)/(ftold+expected))
    	}else{
		grad.unpen.beta <- colSums(-f.first + eventX)
	}

	grad <- grad.unpen.beta-as.vector(S%*%betaold)

	# second derivatives of the cumulative hazard
	deriv.2.list <- lapply(1:n.legendre, function(i) T.X.GL[[i]]%*%(deriv.list[[i]]))

	f.second <- Reduce("+",deriv.2.list)

	# log-likelihoods Hessians
	if (type=="net"){
		Hess.unpen <- -f.second + T.X%*%(eventXexpected*ftold/(ftold+expected)^2)
    	}else{
		Hess.unpen <- -f.second
	}

	Hess <- Hess.unpen-S

	minus.Hess <- -Hess

	R <- try(chol(minus.Hess),silent=TRUE)

	# Hessian perturbation if need be (see Nocedal and Wright 2006)
	if(class(R)=="Error"|class(R)=="try-error")
	{
		u=0.001
		cpt.while <- 0
		while(class(R)=="Error"|class(R)=="try-error")
		{
			if(cpt.while > 100)
			{
				stop("message NR.beta: Ran out of iterations (", cpt.while, "), and did not succeed in inverting Hessian")

			}

			R <- try(chol(minus.Hess+u*diag(p)),silent=TRUE)

			u <- 5*u

			cpt.while <- cpt.while+1

		}

		if (detail.beta) {cat("beta Hessian perturbation, ", cpt.while, "iterations","\n","\n")}
	}

	minus.inv.Hess <- chol2inv(R)


	# cumulative hazard
	integral <- lapply(1:n.legendre, function(i) haz.GL.old[[i]]*leg$weights[i])

	integral <- tm*Reduce("+",integral)

	# log-likelihoods
	if (type=="net"){
		ll.unpenold <- sum(-integral + event*log(ftold+expected))
	}else{
		ll.unpenold <- sum(-integral + event*predold)
	}

	llold <- ll.unpenold-as.numeric(t(betaold)%*%S%*%betaold)*0.5

	if (is.nan(llold)) stop("convergence issues, cannot evaluate log-likelihood")

	# New coef
	pas <- as.vector(minus.inv.Hess%*%grad)

	beta1 <- betaold+pas

	# New hazard
	pred1 <- as.vector(X%*%beta1)
	ft1=as.vector(exp(pred1))

	# New cumulative hazard
	# haz.GL will serve in survPen.fit to derive the derivatives with respect to the smoothing parameters
	haz.GL <- lapply(1:n.legendre, function(i) as.vector(exp((X.GL[[i]]%*%beta1))))

	integral <- lapply(1:n.legendre, function(i) haz.GL[[i]]*leg$weights[i])
	
	integral <- tm*Reduce("+",integral)

	# New log-likelihoods
	if (type=="net"){
		ll.unpen <- sum(-integral + event*log(ft1+expected))
	}else{
		ll.unpen <- sum(-integral + event*pred1)
	}

	ll <- ll.unpen-as.numeric(t(beta1)%*%S%*%beta1)*0.5

	if (is.nan(ll)) {ll <- llold-1}

	if (ll<llold-1e-03){ # at each step, the current log-likelihood should not be inferior to
	# the previous one with a certain tolerence (1e-03)

		# if the penalized log-likelihood is not maximized, the step is halved until it is
		while (ll<llold-1e-03){

			pas <- 0.5*pas

			beta1 <- betaold+pas

			# New hazard
			pred1 <- as.vector(X%*%beta1)
			ft1=as.vector(exp(pred1))

			# New cumulative hazard
			haz.GL <- lapply(1:n.legendre, function(i) as.vector(exp((X.GL[[i]]%*%beta1))))

			integral <- lapply(1:n.legendre, function(i) haz.GL[[i]]*leg$weights[i])

			integral <- tm*Reduce("+",integral)

			# New log-likelihoods
			if (type=="net"){
				ll.unpen <- sum(-integral + event*log(ft1+expected))
			}else{
				ll.unpen <- sum(-integral + event*pred1)
			}

			ll <- ll.unpen-as.numeric(t(beta1)%*%S%*%beta1)*0.5

			if (is.nan(ll)) {ll <- llold-1}
		}

	}

	# convergence details
    if (detail.beta){
      cat("iter beta: ",k,"\n",
          "betaold= ", round(betaold,4),"\n",
          "beta= ", round(beta1,4),"\n",
          "abs((beta-betaold)/betaold)= ", round(abs((beta1-betaold)/betaold),5),"\n",
		  "llold= ", round(llold,4),"\n",
		  "ll= ", round(ll,4),"\n",
          "ll-llold= ", round(ll-llold,5),"\n",
          "\n"
      )
    }

	# next iteration
    k=k+1

  }

  if (detail.beta) {

    cat("------------------","\n",
    "Beta optimization ok, ", k-1, "iterations","\n",
    "------------------","\n")

  }

list(beta.hat=beta1,ll.unpen=ll.unpen,ll=ll,haz.GL=haz.GL,iter.beta=k-1)

}

#----------------------------------------------------------------------------------------------------------------
# END of code : NR.beta
#----------------------------------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------------------------------
# NR.rho : Newton-Raphson algotihm for smoothing parameter estimation via LCV or LAML optimization
#----------------------------------------------------------------------------------------------------------------

#' Outer Newton-Raphson algorithm for smoothing parameters estimation via LCV or LAML optimization
#'
#' Applies Newton-Raphson algorithm for smoothing parameters estimation. Two specific modifications aims at guaranteeing
#' convergence : first the hessian is perturbed whenever it is not positive definite and second, at each step, if LCV or -LAML
#' is not minimized, the step is halved until it is.
#' @param build list of objects returned by \code{\link{model.cons}}
#' @param rho.ini vector of initial log smoothing parameters; if it is NULL, all log lambda are set to -1
#' @param data an optional data frame containing the variables in the model
#' @param formula formula object specifying the model
#' @param max.it.beta maximum number of iterations to reach convergence in the regression coefficients; default is 200
#' @param max.it.rho maximum number of iterations to reach convergence in the smoothing parameters; default is 30
#' @param beta.ini vector of initial regression coefficients; default is NULL, in which case the first beta will be \code{log(sum(event)/sum(t1))} and the others will be zero
#' @param detail.rho if TRUE, details concerning the optimization process in the smoothing parameters are displayed; default is FALSE
#' @param detail.beta if TRUE, details concerning the optimization process in the regression coefficients are displayed; default is FALSE
#' @param nb.smooth number of smoothing parameters
#' @param tol.beta convergence tolerance for regression coefficients; default is \code{1e-04}
#' @param tol.rho convergence tolerance for smoothing parameters; default is \code{1e-04}
#' @param step.max maximum absolute value possible for any component of the step vector (on the log smoothing parameter scale); default is 5
#' @param criterion LCV or LAML; default is LAML
#' @details
#' If we note \code{val} the current LCV or LAML value,
#' \code{val.old} the previous one and \code{grad} the gradient vector of LCV or LAML with respect to the log smoothing parameters, the algorithm goes on
#' \code{while(abs(val-val.old)>tol.rho|any(abs(grad)>tol.rho))}
#'
#' @return object of class survPen (see \code{\link{survPen.fit}} for details)
#' @export
#'
NR.rho <- function(build,rho.ini,data,formula,max.it.beta=200,max.it.rho=30,beta.ini=NULL,detail.rho=FALSE,detail.beta=FALSE,nb.smooth,tol.beta=1e-04,tol.rho=1e-04,step.max=5,criterion="LAML"){

  df.tot <- build$df.tot
 
  iter.beta <- NULL

  k.rho=1
  val=1
  val.old=100

  rho <- rho.ini
  rho.old <- rho.ini

  grad <- rep(1,length(rho))

  if (detail.rho){
  
	cat("------------------------------------------------------------------------------------------","\n",
	"Beginning smoothing parameter(s) selection via ",criterion," optimization","\n",
    "------------------------------------------------------------------------------------------","\n","\n")
	
    }

  while(abs(val-val.old)>tol.rho|any(abs(grad)>tol.rho))
  {

    if(k.rho > max.it.rho)
    {
      stop("message NR.rho : Ran out of iterations (", k.rho, "), and did not converge ")

    }

    if(k.rho>=2)
    {
      val.old <- val
      rho.old <- rho
    }

	if(k.rho==1)
	{

	  lambda=exp(rho.old)

	  build$lambda <- lambda
	  
	  build$S <- matrix(0,df.tot,df.tot)

	  for (i in 1:nb.smooth){

	    build$S.list[[i]] <- lambda[i]*build$S.pen[[i]]

	    build$S <- build$S+build$S.list[[i]]

	  }

	  model <- survPen.fit(build,data=data,formula=formula,max.it.beta=max.it.beta,beta.ini=beta.ini,detail.beta=detail.beta,criterion=criterion,tol.beta=tol.beta)
	  beta1 <- model$beta.hat
	  iter.beta <- c(iter.beta,model$iter.beta)
	}
	
	# LAML
	val.old=model$criterion.val

    # gradient
	grad <- model$grad.rho

	# Hessian
	Hess <- model$Hess.rho

	R <- try(chol(Hess),silent=TRUE)

	# Hessian perturbation
	if(class(R)=="Error"|class(R)=="try-error")
	{

		u=0.001
		cpt.while <- 0
		while(class(R)=="Error"|class(R)=="try-error")
		{

			if(cpt.while > 100)
			{
				stop("message NR.rho : Ran out of iterations ", cpt.while, ", and did not succeed in inverting Hessian ","\n","\n")

			}

			R <- try(chol(Hess+u*diag(nb.smooth)),silent=TRUE)

			u <- 5*u

			cpt.while <- cpt.while+1

		}

		if (detail.rho) {cat(criterion," Hessian perturbation, ", cpt.while, "iterations","\n","\n")}
	}

	inv.Hess <- chol2inv(R)

	# New rho
	pas <- -as.vector(inv.Hess%*%grad)
	
	norm.pas <- max(abs(pas))

	if (norm.pas>step.max){
		
		if (detail.rho) {
		
			cat("new step = ", signif(pas,3),"\n")
		
		}
		
		pas <- (step.max/norm.pas)*pas

		if (detail.rho) {
		
			cat("new step corrected = ", signif(pas,3),"\n","\n")
		
		}
		
	}

	rho <- rho.old+pas

	lambda=exp(rho)
	
	build$lambda <- lambda
	
	build$S <- matrix(0,df.tot,df.tot)

	for (i in 1:nb.smooth){

	  build$S.list[[i]] <- lambda[i]*build$S.pen[[i]]

	  build$S <- build$S+build$S.list[[i]]

	}

	model <- survPen.fit(build,data=data,formula=formula,max.it.beta=max.it.beta,beta.ini=beta1,detail.beta=detail.beta,criterion=criterion,tol.beta=tol.beta)
	beta1 <- model$beta.hat

	val <- model$criterion.val

	if (is.nan(val)) {val <- val.old+1}

	if (val>val.old+1e-03){

	  cpt.rho <- 1

		while (val>val.old+1e-03){

			if (detail.rho) {

			cat("------------------------------------------------------------------------------------------","\n",
			"val= ", val," et val.old= ", val.old,"\n",
			criterion," is not optimized at iteration ", k.rho,"\n",
			"Step is divided by 10","\n",
		    "------------------------------------------------------------------------------------------","\n","\n")

			}

			if(cpt.rho>10) stop("step has been divided by ten ten times in a row, LAML could not be optimized")

		  	cpt.rho <- cpt.rho+1

			pas <- 0.1*pas

			rho <- rho.old+pas

			lambda=exp(rho)

			build$lambda <- lambda
			
			build$S <- matrix(0,df.tot,df.tot)

			for (i in 1:nb.smooth){

			  build$S.list[[i]] <- lambda[i]*build$S.pen[[i]]

			  build$S <- build$S+build$S.list[[i]]

			}

			model <- survPen.fit(build,data=data,formula=formula,max.it.beta=max.it.beta,beta.ini=beta1,detail.beta=detail.beta,criterion=criterion,tol.beta=tol.beta)
			beta1 <- model$beta.hat

			val <- model$criterion.val

			if (is.nan(val)) {val <- val.old+1}

		}

	}

	iter.beta <- c(iter.beta,model$iter.beta)

	beta1 <- model$beta.hat
	val <- model$criterion.val
	grad <- model$grad.rho
	Hess <- model$Hess.rho

	# convergence details
    if (detail.rho){
      cat("\n","iter ",criterion,": ",k.rho,"\n",
          "rho.old= ", round(rho.old,4),"\n",
          "rho= ", round(rho,4),"\n",
		  "val.old= ", round(val.old,4),"\n",
		  "val= ", round(val,4),"\n",
          "val-val.old= ", round(val-val.old,5),"\n",
		  "gradient= ", signif(grad,2),"\n",
          "\n"
      )
	  cat("------------------------------------------------------------------------------------------","\n")
    }

	# next iteration
    k.rho=k.rho+1

  }

	if (detail.rho) {

	cat("Smoothing parameter(s) selection via ",criterion," ok, ", k.rho-1, "iterations","\n",
    "------------------------------------------------------------------------------------------","\n")

	}

	Hess.rho.modif <- FALSE

	R <- try(chol(Hess),silent=TRUE)

	# Hessian perturbation at convergence
	if(class(R)=="Error"|class(R)=="try-error")
	{
		Hess.rho.modif <- TRUE
		
		eigen.temp <- eigen(Hess,symmetric=TRUE)
		U.temp <- eigen.temp$vectors
		vp.temp <- eigen.temp$values

		vp.temp[which(vp.temp<1e-7)] <- 1e-7

		R <- try(chol(U.temp%*%diag(vp.temp)%*%t(U.temp)),silent=TRUE)

		warning("rho Hessian was perturbed at convergence")
	}

	model$inv.Hess.rho <- chol2inv(R)
	
	model$Hess.rho <- t(R)%*%R
	
	model$Hess.rho.modif <- Hess.rho.modif

	model$iter.rho <- k.rho-1

	model$iter.beta <- iter.beta

	model$optim.rho <- 1 # so we can identify whether the smoothing parameters were estimated or not
	
	model

}

#----------------------------------------------------------------------------------------------------------------
# END of code : NR.rho
#----------------------------------------------------------------------------------------------------------------

#################################################################################################################

